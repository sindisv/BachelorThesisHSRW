package com.example.myapplication.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [ImuReading::class],
    version = 3,                    // ← bumped from 2 to 3
    exportSchema = false
)
abstract class BLEDatabase : RoomDatabase() {

    abstract fun imuDao(): ImuDao

    companion object {

        @Volatile
        private var INSTANCE: BLEDatabase? = null

        // Migration 1 → 2: added sessionId and sessionName
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE imu_readings ADD COLUMN sessionId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE imu_readings ADD COLUMN sessionName TEXT NOT NULL DEFAULT ''")
            }
        }

        // Migration 2 → 3: added deviceId and bodyLocation
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE imu_readings ADD COLUMN deviceId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE imu_readings ADD COLUMN bodyLocation TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getInstance(context: Context): BLEDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    BLEDatabase::class.java,
                    "imu_database"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}