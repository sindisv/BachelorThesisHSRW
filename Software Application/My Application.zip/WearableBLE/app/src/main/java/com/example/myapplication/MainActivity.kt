package com.example.myapplication

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.myapplication.ble.BleManager
import com.example.myapplication.ble.ImuSample
import com.example.myapplication.db.BLEDatabase
import com.example.myapplication.db.ImuReading
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter

// ── Device colors ─────────────────────────────────────────────────────────────
val DeviceColors = mapOf(
    1 to Color(0xFF2196F3),
    2 to Color(0xFF4CAF50),
    3 to Color(0xFFFF9800),
    4 to Color(0xFFE53935),
)

class MainActivity : ComponentActivity() {

    private lateinit var bleManager: BleManager
    private lateinit var db: BLEDatabase

    // ── UI state ──────────────────────────────────────────────────────────────
    private val statusText       = mutableStateOf("Press Connect Sensors to Establish Connection")
    private val recentSamples    = mutableStateListOf<String>()
    private val exportStatus     = mutableStateOf("")
    private val showExportDialog = mutableStateOf(false)

    // ── Device connections ────────────────────────────────────────────────────
    private val device1Connected = mutableStateOf(false)
    private val device2Connected = mutableStateOf(false)
    private val device3Connected = mutableStateOf(false)
    private val device4Connected = mutableStateOf(false)

    // ── Device locations ──────────────────────────────────────────────────────
    private val device1Location  = mutableStateOf("None")
    private val device2Location  = mutableStateOf("None")
    private val device3Location  = mutableStateOf("None")
    private val device4Location  = mutableStateOf("None")

    // ── Session state ─────────────────────────────────────────────────────────
    private val currentSessionId   = mutableLongStateOf(0L)
    private val currentSessionName = mutableStateOf("")
    private val sessionRowCount    = mutableIntStateOf(0)
    private val isSessionActive    = mutableStateOf(false)
    private val showSessionDialog  = mutableStateOf(false)
    private val sessionNameInput   = mutableStateOf("")
    private val sessionStartTime   = mutableLongStateOf(0L)
    private val sessionElapsedTime = mutableStateOf("00:00:00")

    // ── Sequence capture state ──────────────────────────────────────────────────
    // When a session ends, we show the sequence builder for the just-ended session.
    private val showSequenceDialog   = mutableStateOf(false)
    private val sequenceForSession    = mutableStateOf("")   // session name the sequence is for
    // Stored sequences in memory, keyed by session name (also written to disk on export)
    private val savedSequences = mutableMapOf<String, PerformedSequence>()

    // ── Session list ──────────────────────────────────────────────────────────
    private val allSessionNames = mutableStateListOf<String>()

    // ── Navigation ────────────────────────────────────────────────────────────
    private val showGraphScreen    = mutableStateOf(false)
    private val showGraphPicker    = mutableStateOf(false)
    private val selectedSession    = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = BLEDatabase.getInstance(this)
        bleManager = BleManager(
            context              = this,
            onSamplesReceived    = { samples, deviceId, _ -> saveSamples(samples, deviceId) },
            onDeviceStateChanged = { deviceId, connected   -> updateDeviceState(deviceId, connected) }
        )
        requestPermissions()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            MyApplicationTheme {

                // Reload session list whenever we return to the main screen
                LaunchedEffect(showGraphScreen.value) {
                    if (!showGraphScreen.value) {
                        val names = withContext(Dispatchers.IO) {
                            db.imuDao().getAllSessions().map { it.sessionName }.reversed()
                        }
                        allSessionNames.clear()
                        allSessionNames.addAll(names)
                    }
                }

                when {
                    showGraphScreen.value -> {
                        SessionGraphScreen(
                            sessionName = selectedSession.value,
                            db          = db,
                            onBack      = { showGraphScreen.value = false }
                        )
                    }
                    else -> {
                        // Session name dialog
                        if (showSessionDialog.value) {
                            SessionNameDialog(
                                sessionNameInput = sessionNameInput.value,
                                onNameChange     = { sessionNameInput.value = it },
                                onConfirm        = { startSession() },
                                onDismiss        = { showSessionDialog.value = false }
                            )
                        }

                        // Sequence builder — shown after a session ends
                        if (showSequenceDialog.value) {
                            SequenceBuilderDialog(
                                onConfirm = { seq ->
                                    savedSequences[sequenceForSession.value] = seq
                                    showSequenceDialog.value = false
                                    exportStatus.value =
                                        "Sequence saved for '${sequenceForSession.value}'. " +
                                                "Export to write it to disk."
                                    lifecycleScope.launch {
                                        delay(5000); exportStatus.value = ""
                                    }
                                },
                                onDismiss = {
                                    // user skipped — no sequence stored
                                    showSequenceDialog.value = false
                                }
                            )
                        }

                        // Export dialog
                        if (showExportDialog.value) {
                            ExportDialog(
                                onDismiss    = { showExportDialog.value = false },
                                onExportDays = { days ->
                                    showExportDialog.value = false
                                    exportSessions(days)
                                }
                            )
                        }
                        // Graph session picker
                        if (showGraphPicker.value) {
                            SessionPickerDialog(
                                sessions      = allSessionNames,
                                title         = "View Session Graph",
                                onSessionPick = { name ->
                                    showGraphPicker.value = false
                                    selectedSession.value = name
                                    showGraphScreen.value = true
                                },
                                onDismiss = { showGraphPicker.value = false }
                            )
                        }
                        MainScreen(
                            status             = statusText.value,
                            recentSamples      = recentSamples,
                            exportStatus       = exportStatus.value,
                            isSessionActive    = isSessionActive.value,
                            currentSessionName = currentSessionName.value,
                            sessionRowCount    = sessionRowCount.intValue,
                            sessionElapsedTime = sessionElapsedTime.value,
                            device1Connected   = device1Connected.value,
                            device2Connected   = device2Connected.value,
                            device3Connected   = device3Connected.value,
                            device4Connected   = device4Connected.value,
                            device1Location    = device1Location.value,
                            device2Location    = device2Location.value,
                            device3Location    = device3Location.value,
                            device4Location    = device4Location.value,
                            sessionCount       = allSessionNames.size,
                            onDevice1LocationChange = { device1Location.value = it },
                            onDevice2LocationChange = { device2Location.value = it },
                            onDevice3LocationChange = { device3Location.value = it },
                            onDevice4LocationChange = { device4Location.value = it },
                            onConnectClick    = { startScanning() },
                            onDisconnectClick = { stopScanning() },
                            onNewSessionClick = { showSessionDialog.value = true },
                            onEndSessionClick = { endSession() },
                            onExportClick     = { showExportDialog.value = true },
                            onViewGraphClick  = { showGraphPicker.value = true },
                        )
                    }
                }
            }
        }
    }

    // ── Export CSV (+ sequence files where available) ───────────────────────────
    private fun exportSessions(daysBack: Int) {
        lifecycleScope.launch {
            try {
                val allSessions = withContext(Dispatchers.IO) {
                    db.imuDao().getAllSessions()
                }
                if (allSessions.isEmpty()) {
                    exportStatus.value = "No sessions to export"
                    return@launch
                }
                val toExport = when (daysBack) {
                    1    -> allSessions.takeLast(3)
                    2    -> allSessions.takeLast(8)
                    3    -> allSessions.takeLast(15)
                    else -> allSessions
                }
                val dir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var fileCount = 0
                var rowCount  = 0
                var seqCount  = 0
                withContext(Dispatchers.IO) {
                    for (session in toExport) {
                        val readings = db.imuDao().getSessionReadings(session.sessionId)
                        if (readings.isEmpty()) continue

                        // 1. Standard IMU CSV — UNCHANGED format
                        val file = File(dir, "${session.sessionName.replace(" ", "_")}.csv")
                        FileWriter(file).use { w ->
                            w.append("session_name,device_id,body_location," +
                                    "device_ts_ms,wall_clock_ms," +
                                    "accel_x,accel_y,accel_z," +
                                    "gyro_x,gyro_y,gyro_z," +
                                    "quat_w,quat_x,quat_y,quat_z\n")
                            for (r in readings) {
                                w.append("${r.sessionName},${r.deviceId},${r.bodyLocation}," +
                                        "${r.deviceTimestampMs},${r.wallClockMs}," +
                                        "${r.accelX},${r.accelY},${r.accelZ}," +
                                        "${r.gyroX},${r.gyroY},${r.gyroZ}," +
                                        "${r.quatW},${r.quatX},${r.quatY},${r.quatZ}\n")
                            }
                        }
                        fileCount++
                        rowCount += readings.size

                        // 2. Sequence note + labels — only if a sequence was entered
                        val seq = savedSequences[session.sessionName]
                        if (seq != null) {
                            SequenceExport.exportSequenceNote(session.sessionName, seq)
                            SequenceExport.exportLabels(session.sessionName, readings, seq)
                            seqCount++
                        }
                    }
                }
                exportStatus.value = if (seqCount > 0)
                    "✓ Saved $fileCount CSV files ($rowCount rows) + $seqCount sequence/label files to Downloads/"
                else
                    "✓ Saved $fileCount CSV files ($rowCount rows) to Downloads/"
                delay(6000)
                exportStatus.value = ""
            } catch (e: Exception) {
                exportStatus.value = "Export error: ${e.message}"
            }
        }
    }

    // ── Device state ──────────────────────────────────────────────────────────
    private fun updateDeviceState(deviceId: Int, connected: Boolean) {
        when (deviceId) {
            1 -> device1Connected.value = connected
            2 -> device2Connected.value = connected
            3 -> device3Connected.value = connected
            4 -> device4Connected.value = connected
        }
        val count = bleManager.getConnectedCount()
        statusText.value = when {
            connected  -> "Connected: $count/4 sensors"
            count == 0 -> "Ready — tap Connect Sensors"
            else       -> "$count/4 sensors connected"
        }
    }

    // ── BLE ───────────────────────────────────────────────────────────────────
    private fun startScanning() {
        statusText.value = "Scanning for sensors…"
        bleManager.startScan()
    }

    private fun stopScanning() {
        if (isSessionActive.value) endSession()
        bleManager.disconnectAll()
        statusText.value       = "Disconnected"
        device1Connected.value = false
        device2Connected.value = false
        device3Connected.value = false
        device4Connected.value = false
    }

    // ── Session ───────────────────────────────────────────────────────────────
    private fun startSession() {
        val name = sessionNameInput.value.trim()
        if (name.isEmpty()) return
        showSessionDialog.value = false
        lifecycleScope.launch {
            val newId = withContext(Dispatchers.IO) { db.imuDao().getNextSessionId() }
            currentSessionId.longValue   = newId
            currentSessionName.value     = name
            sessionRowCount.intValue     = 0
            isSessionActive.value        = true
            sessionNameInput.value       = ""
            sessionStartTime.longValue   = System.currentTimeMillis()
            sessionElapsedTime.value     = "00:00:00"
            statusText.value             = "● Recording: $name"
            startSessionTimer()
        }
    }

    private fun startSessionTimer() {
        lifecycleScope.launch {
            while (isSessionActive.value) {
                val e = System.currentTimeMillis() - sessionStartTime.longValue
                sessionElapsedTime.value = "%02d:%02d:%02d".format(
                    e / 3600000, (e % 3600000) / 60000, (e % 60000) / 1000)
                delay(1000)
            }
        }
    }

    private fun endSession() {
        isSessionActive.value = false
        val name = currentSessionName.value
        val rows = sessionRowCount.intValue
        val dur  = sessionElapsedTime.value
        currentSessionId.longValue   = 0L
        currentSessionName.value     = ""
        sessionRowCount.intValue     = 0
        sessionElapsedTime.value     = "00:00:00"
        statusText.value             = "Session '$name' saved — $rows rows · $dur"

        // Trigger the sequence builder for the just-ended session
        if (name.isNotBlank() && rows > 0) {
            sequenceForSession.value = name
            showSequenceDialog.value = true
        }

        // Refresh session list
        lifecycleScope.launch {
            val names = withContext(Dispatchers.IO) {
                db.imuDao().getAllSessions().map { it.sessionName }.reversed()
            }
            allSessionNames.clear()
            allSessionNames.addAll(names)
        }
    }

    // ── Save samples ──────────────────────────────────────────────────────────
    private fun saveSamples(samples: List<ImuSample>, deviceId: Int) {
        if (!isSessionActive.value) return
        lifecycleScope.launch {
            val now                = System.currentTimeMillis()
            val sessionId          = currentSessionId.longValue
            val sessionName        = currentSessionName.value
            val deviceTsAtCallback = samples.lastOrNull()?.timestamp ?: 0L
            val readings = samples.map { s ->
                ImuReading(
                    sessionId         = sessionId,
                    sessionName       = sessionName,
                    deviceId          = deviceId,
                    bodyLocation      = getDeviceLocation(deviceId),
                    deviceTimestampMs = s.timestamp,
                    wallClockMs       = now + (s.timestamp - deviceTsAtCallback),
                    accelX = s.accelX, accelY = s.accelY, accelZ = s.accelZ,
                    gyroX  = s.gyroX,  gyroY  = s.gyroY,  gyroZ  = s.gyroZ,
                    quatW  = s.quatW,  quatX  = s.quatX,
                    quatY  = s.quatY,  quatZ  = s.quatZ
                )
            }
            withContext(Dispatchers.IO) { db.imuDao().insertAll(readings) }
            val count = withContext(Dispatchers.IO) {
                db.imuDao().sessionRowCount(sessionId)
            }
            if (isSessionActive.value) sessionRowCount.intValue = count
            readings.lastOrNull()?.let { r ->
                val line = "[D$deviceId ${getDeviceLocation(deviceId)}] " +
                        "ax=%.2f ay=%.2f az=%.2f".format(r.accelX, r.accelY, r.accelZ)
                val idx = recentSamples.indexOfFirst { it.startsWith("[D$deviceId") }
                if (idx >= 0) recentSamples[idx] = line else recentSamples.add(line)
            }
        }
    }

    private fun getDeviceLocation(deviceId: Int) = when (deviceId) {
        1 -> device1Location.value
        2 -> device2Location.value
        3 -> device3Location.value
        4 -> device4Location.value
        else -> "Unknown"
    }

    // ── Permissions ───────────────────────────────────────────────────────────
    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()) {}

    private fun requestPermissions() {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms += Manifest.permission.BLUETOOTH_SCAN
            perms += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
        }
        permLauncher.launch(perms.toTypedArray())
    }

    override fun onDestroy() {
        super.onDestroy()
        bleManager.disconnectAll()
    }
}

// ── Dialogs ───────────────────────────────────────────────────────────────────

@Composable
fun ExportDialog(onDismiss: () -> Unit, onExportDays: (Int) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export Sessions to CSV") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Files saved to the tablet Downloads folder. " +
                        "Sessions with a recorded sequence also export sequence + label files.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline)
                Spacer(Modifier.height(4.dp))
                Button(onClick = { onExportDays(0) },
                    modifier = Modifier.fillMaxWidth()) { Text("Export ALL sessions") }
                OutlinedButton(onClick = { onExportDays(1) },
                    modifier = Modifier.fillMaxWidth()) { Text("Last ~1 day  (3 most recent)") }
                OutlinedButton(onClick = { onExportDays(2) },
                    modifier = Modifier.fillMaxWidth()) { Text("Last ~2 days  (8 most recent)") }
                OutlinedButton(onClick = { onExportDays(3) },
                    modifier = Modifier.fillMaxWidth()) { Text("Last ~3 days  (15 most recent)") }
            }
        },
        confirmButton = {},
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SessionNameDialog(
    sessionNameInput: String,
    onNameChange:     (String) -> Unit,
    onConfirm:        () -> Unit,
    onDismiss:        () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Session name") },
        text = {
            OutlinedTextField(
                value         = sessionNameInput,
                onValueChange = onNameChange,
                label         = { Text("e.g. Jab_Left_Wrist") },
                singleLine    = true,
                modifier      = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(onClick  = onConfirm,
                enabled  = sessionNameInput.trim().isNotEmpty()) {
                Text("Start Recording")
            }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ── Main screen ───────────────────────────────────────────────────────────────

@Composable
fun MainScreen(
    status:             String,
    recentSamples:      List<String>,
    exportStatus:       String,
    isSessionActive:    Boolean,
    currentSessionName: String,
    sessionRowCount:    Int,
    sessionElapsedTime: String,
    device1Connected:   Boolean,
    device2Connected:   Boolean,
    device3Connected:   Boolean,
    device4Connected:   Boolean,
    device1Location:    String,
    device2Location:    String,
    device3Location:    String,
    device4Location:    String,
    sessionCount:       Int,
    onDevice1LocationChange: (String) -> Unit,
    onDevice2LocationChange: (String) -> Unit,
    onDevice3LocationChange: (String) -> Unit,
    onDevice4LocationChange: (String) -> Unit,
    onConnectClick:    () -> Unit,
    onDisconnectClick: () -> Unit,
    onNewSessionClick: () -> Unit,
    onEndSessionClick: () -> Unit,
    onExportClick:     () -> Unit,
    onViewGraphClick:  () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Boxing Training Tracker",
            style      = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold)

        // Status card
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(status,
                modifier = Modifier.padding(14.dp),
                style    = MaterialTheme.typography.bodyMedium)
        }

        // Devices card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Sensors", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                DeviceStatusRow(1, device1Connected, device1Location, onDevice1LocationChange)
                DeviceStatusRow(2, device2Connected, device2Location, onDevice2LocationChange)
                DeviceStatusRow(3, device3Connected, device3Location, onDevice3LocationChange)
                DeviceStatusRow(4, device4Connected, device4Location, onDevice4LocationChange)
            }
        }

        // BLE buttons
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onConnectClick, modifier = Modifier.weight(1f)) {
                Text("Connect Sensors") }
            OutlinedButton(onClick = onDisconnectClick, modifier = Modifier.weight(1f)) {
                Text("Disconnect") }
        }

        // Active session card
        if (isSessionActive) {
            Card(modifier = Modifier.fillMaxWidth(),
                colors   = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("● RECORDING",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error)
                    Text(currentSessionName,
                        style      = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("$sessionRowCount rows",
                            style = MaterialTheme.typography.bodyMedium)
                        Text(sessionElapsedTime,
                            style      = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Session buttons
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick  = onNewSessionClick, enabled  = !isSessionActive,
                modifier = Modifier.weight(1f),
                colors   = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.tertiary)) {
                Text("New Session") }
            Button(onClick  = onEndSessionClick, enabled  = isSessionActive,
                modifier = Modifier.weight(1f),
                colors   = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error)) {
                Text("End Session") }
        }

        // Session count info
        Card(modifier = Modifier.fillMaxWidth()) {
            Row(modifier              = Modifier.padding(14.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically) {
                Text("Sessions stored on tablet",
                    style = MaterialTheme.typography.bodyMedium)
                Text("$sessionCount sessions",
                    style      = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold)
            }
        }

        // Export
        Button(onClick  = onExportClick,
            modifier = Modifier.fillMaxWidth(),
            enabled  = !isSessionActive,
            colors   = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary)) {
            Text("Export Sessions to Downloads (CSV)") }

        if (exportStatus.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth(),
                colors   = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text(exportStatus, modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodySmall)
            }
        }

        // View graph — picks session
        OutlinedButton(onClick  = onViewGraphClick,
            modifier = Modifier.fillMaxWidth(),
            enabled  = !isSessionActive && sessionCount > 0) {
            Text("View Session Graph  ($sessionCount sessions)") }

        // Live readings
        if (recentSamples.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Live sensor readings",
                        style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(6.dp))
                    recentSamples.toList().forEach {
                        Text(it, style = MaterialTheme.typography.bodySmall)
                        HorizontalDivider(Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        }
    }
}

// ── Device status row ─────────────────────────────────────────────────────────

@Composable
fun DeviceStatusRow(
    deviceId:         Int,
    connected:        Boolean,
    location:         String,
    onLocationChange: (String) -> Unit,
) {
    val options = listOf("None","Right Wrist","Left Wrist",
        "Right Ankle","Left Ankle","Custom…")
    var expanded         by remember { mutableStateOf(false) }
    var showCustomDialog by remember { mutableStateOf(false) }
    var customInput      by remember { mutableStateOf("") }
    val deviceColor      = DeviceColors[deviceId] ?: Color.Gray

    if (showCustomDialog) {
        AlertDialog(
            onDismissRequest = { showCustomDialog = false },
            title = { Text("Custom location") },
            text = {
                OutlinedTextField(
                    value = customInput, onValueChange = { customInput = it },
                    label = { Text("e.g. Right Shin") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                Button(onClick = {
                    if (customInput.isNotEmpty()) onLocationChange(customInput)
                    customInput = ""; showCustomDialog = false
                }) { Text("Set") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showCustomDialog = false }) { Text("Cancel") }
            }
        )
    }

    Row(modifier              = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically) {

        Box(modifier         = Modifier
            .size(28.dp).clip(CircleShape)
            .background(if (connected) deviceColor else Color.LightGray)
            .border(1.5.dp,
                if (connected) deviceColor.copy(alpha = 0.5f) else Color.Gray,
                CircleShape),
            contentAlignment = Alignment.Center) {
            Text("$deviceId",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White)
        }

        Spacer(Modifier.width(8.dp))

        Text(if (connected) "Connected" else "Not found",
            style    = MaterialTheme.typography.labelSmall,
            color    = if (connected) deviceColor else MaterialTheme.colorScheme.outline,
            modifier = Modifier.width(72.dp))

        Box(modifier = Modifier.weight(1f)) {
            OutlinedButton(
                onClick        = { expanded = true },
                modifier       = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                border         = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (connected) deviceColor.copy(alpha = 0.6f)
                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            ) {
                Text(location,
                    style    = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f))
                Text("▾", style = MaterialTheme.typography.bodySmall)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { opt ->
                    DropdownMenuItem(
                        text    = { Text(opt, style = MaterialTheme.typography.bodySmall) },
                        onClick = {
                            expanded = false
                            if (opt == "Custom…") showCustomDialog = true
                            else onLocationChange(opt)
                        })
                }
            }
        }
    }
}

// ── Unused but required stub to satisfy TextAlign import if used elsewhere ────
private val _unusedTextAlign = TextAlign.Center