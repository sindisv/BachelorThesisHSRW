package com.example.myapplication.ble

// Plain data class shared by BLE parser, Room entity, and upload serializer
// Represents one single IMU reading received from the XIAO over BLE
data class ImuSample(
    val timestamp: Long,    // milliseconds from XIAO boot
    val accelX: Float,
    val accelY: Float,
    val accelZ: Float,
    val gyroX: Float,
    val gyroY: Float,
    val gyroZ: Float,
    val quatW: Float,
    val quatX: Float,
    val quatY: Float,
    val quatZ: Float
)