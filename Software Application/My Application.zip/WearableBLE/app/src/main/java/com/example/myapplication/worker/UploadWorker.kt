package com.example.myapplication.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.myapplication.db.BLEDatabase
import com.example.myapplication.network.ApiService

class UploadWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val tag = "UploadWorker"
    private val batchSize = 500

    override suspend fun doWork(): Result {
        val db = BLEDatabase.getInstance(applicationContext)
        val api = ApiService.create()

        return try {
            // Check Pi is reachable
            val ping = api.ping()
            if (!ping.isSuccessful) {
                Log.w(tag, "Pi not reachable — will retry later")
                return Result.retry()
            }

            // Upload ALL unsent rows in batches of 200
            var totalUploaded = 0
            while (true) {
                val batch = db.imuDao().getUnsentBatch(batchSize)
                if (batch.isEmpty()) break

                val response = api.ingest(batch)
                if (response.isSuccessful) {
                    val ids = batch.map { it.id }
                    db.imuDao().markAsSent(ids)
                    db.imuDao().deleteSent()
                    totalUploaded += batch.size
                    Log.d(tag, "Uploaded batch of ${batch.size} — total so far: $totalUploaded")
                } else {
                    Log.e(tag, "Batch upload failed — server returned ${response.code()}")
                    return Result.retry()
                }
            }

            Log.d(tag, "All done — uploaded $totalUploaded rows total")
            Result.success()

        } catch (e: Exception) {
            Log.e(tag, "Upload error: ${e.message}")
            Result.retry()
        }
    }
}