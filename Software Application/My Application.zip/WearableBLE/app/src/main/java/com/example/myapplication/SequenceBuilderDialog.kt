package com.example.myapplication

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/**
 * Dialog shown at session end to record the performed sequence.
 *
 * Four modes via tabs:
 *   Structured  — tap motions in order, optional repeat counts
 *   One motion  — whole session was a single motion (e.g. all jabs), no count
 *   Free round  — unstructured sparring, optional note
 *   Free text   — typed description
 */
@Composable
fun SequenceBuilderDialog(
    onConfirm: (PerformedSequence) -> Unit,
    onDismiss: () -> Unit,
) {
    var mode by remember { mutableStateOf(SequenceMode.STRUCTURED) }

    // Structured state
    val entries      = remember { mutableStateListOf<SequenceEntry>() }
    val currentCombo = remember { mutableStateListOf<String>() }
    var repeatText   by remember { mutableStateOf("1") }
    var countUnknown by remember { mutableStateOf(false) }

    // Whole-session-one-motion state
    var wholeMotion by remember { mutableStateOf("") }

    // Free text / round note
    var freeText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier
                .padding(18.dp)
                .verticalScroll(rememberScrollState())
                .heightIn(max = 640.dp)) {

                Text("Record what was performed",
                    fontWeight = FontWeight.Bold, fontSize = 17.sp,
                    color = Color(0xFF212121))
                Text("Becomes the ground-truth label for this session.",
                    fontSize = 11.sp, color = Color(0xFF888888))
                Spacer(Modifier.height(10.dp))

                // Mode tabs (wrap into two rows of chips)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ModeChip("Sequence", mode == SequenceMode.STRUCTURED) {
                            mode = SequenceMode.STRUCTURED }
                        ModeChip("One motion", mode == SequenceMode.WHOLE_SESSION_ONE_MOTION) {
                            mode = SequenceMode.WHOLE_SESSION_ONE_MOTION }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ModeChip("Free round", mode == SequenceMode.FREE_ROUND) {
                            mode = SequenceMode.FREE_ROUND }
                        ModeChip("Free text", mode == SequenceMode.FREE_TEXT) {
                            mode = SequenceMode.FREE_TEXT }
                    }
                }

                Spacer(Modifier.height(12.dp))

                when (mode) {
                    SequenceMode.STRUCTURED -> StructuredEditor(
                        entries, currentCombo, repeatText, countUnknown,
                        onRepeatChange = { repeatText = it },
                        onUnknownChange = { countUnknown = it },
                        onAddEntry = {
                            entries.add(SequenceEntry(
                                currentCombo.toList(),
                                repeatText.toIntOrNull() ?: 1,
                                !countUnknown))
                            currentCombo.clear(); repeatText = "1"; countUnknown = false
                        })

                    SequenceMode.WHOLE_SESSION_ONE_MOTION -> {
                        Text("The whole session was one motion type:",
                            fontSize = 12.sp, fontWeight = FontWeight.Medium,
                            color = Color(0xFF555555))
                        Spacer(Modifier.height(8.dp))
                        MotionChoiceGrid(selected = wholeMotion) { wholeMotion = it }
                        if (wholeMotion.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Surface(color = Color(0xFFF0F4FF), shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()) {
                                Text("Every detected strike → $wholeMotion",
                                    modifier = Modifier.padding(10.dp),
                                    fontSize = 13.sp, fontWeight = FontWeight.Medium,
                                    color = Color(0xFF1565C0))
                            }
                        }
                    }

                    SequenceMode.FREE_ROUND -> {
                        Text("Free round / sparring — no fixed sequence.",
                            fontSize = 12.sp, color = Color(0xFF555555))
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = freeText, onValueChange = { freeText = it },
                            label = { Text("Optional note") },
                            placeholder = { Text("e.g. 3-minute free round") },
                            modifier = Modifier.fillMaxWidth())
                    }

                    SequenceMode.FREE_TEXT -> {
                        OutlinedTextField(
                            value = freeText, onValueChange = { freeText = it },
                            label = { Text("Describe the sequence") },
                            placeholder = { Text("e.g. jab, jab, cross, hook repeated") },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp))
                    }
                }

                Spacer(Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Skip") }
                    Button(
                        onClick = {
                            val seq = when (mode) {
                                SequenceMode.STRUCTURED -> PerformedSequence(
                                    mode = mode, entries = entries.toList())
                                SequenceMode.WHOLE_SESSION_ONE_MOTION -> PerformedSequence(
                                    mode = mode, wholeSessionMotion = wholeMotion)
                                else -> PerformedSequence(mode = mode, freeText = freeText)
                            }
                            onConfirm(seq)
                        },
                        modifier = Modifier.weight(1f),
                        enabled = when (mode) {
                            SequenceMode.STRUCTURED -> entries.isNotEmpty()
                            SequenceMode.WHOLE_SESSION_ONE_MOTION -> wholeMotion.isNotBlank()
                            else -> true
                        }
                    ) { Text("Save") }
                }
            }
        }
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick,
        label = { Text(label, fontSize = 12.sp) })
}

@Composable
private fun StructuredEditor(
    entries: MutableList<SequenceEntry>,
    currentCombo: MutableList<String>,
    repeatText: String,
    countUnknown: Boolean,
    onRepeatChange: (String) -> Unit,
    onUnknownChange: (Boolean) -> Unit,
    onAddEntry: () -> Unit,
) {
    Text("Tap motions in order to build one entry:",
        fontSize = 12.sp, color = Color(0xFF555555), fontWeight = FontWeight.Medium)
    Spacer(Modifier.height(6.dp))
    MotionButtonRow(MotionVocabulary.punches) { currentCombo.add(it) }
    Spacer(Modifier.height(4.dp))
    MotionButtonRow(MotionVocabulary.kicks) { currentCombo.add(it) }
    Spacer(Modifier.height(10.dp))

    if (currentCombo.isNotEmpty()) {
        Surface(color = Color(0xFFF0F4FF), shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(currentCombo.joinToString(" - "),
                    fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f), color = Color(0xFF1565C0))
                TextButton(onClick = { currentCombo.clear() }) { Text("Clear", fontSize = 12.sp) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Repeat", fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(
                value = repeatText,
                onValueChange = { onRepeatChange(it.filter { c -> c.isDigit() }) },
                modifier = Modifier.width(72.dp), singleLine = true, enabled = !countUnknown)
            Spacer(Modifier.width(8.dp))
            Text("times", fontSize = 12.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = countUnknown, onCheckedChange = onUnknownChange)
            Text("I don't know the count", fontSize = 11.sp, color = Color(0xFF555555))
        }
        Button(onClick = onAddEntry, modifier = Modifier.fillMaxWidth()) { Text("Add entry") }
    }

    Spacer(Modifier.height(12.dp))
    if (entries.isNotEmpty()) {
        Text("Sequence so far:", fontSize = 12.sp, fontWeight = FontWeight.Medium,
            color = Color(0xFF555555))
        Spacer(Modifier.height(4.dp))
        entries.forEachIndexed { idx, e ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically) {
                val combo = e.motions.joinToString("-")
                val label = when {
                    !e.countKnown -> "$combo (×?)"; e.repeat == 1 -> combo
                    else -> "$combo ×${e.repeat}" }
                Text("${idx + 1}. $label", fontSize = 12.sp,
                    modifier = Modifier.weight(1f), color = Color(0xFF333333))
                TextButton(onClick = { entries.removeAt(idx) }) {
                    Text("✕", fontSize = 12.sp, color = Color(0xFFE53935)) }
            }
        }
    }
}

@Composable
private fun MotionButtonRow(motions: List<String>, onTap: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        motions.forEach { motion ->
            OutlinedButton(
                onClick = { onTap(motion) },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp),
            ) { Text(shortName(motion), fontSize = 10.sp, maxLines = 1) }
        }
    }
}

@Composable
private fun MotionChoiceGrid(selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        MotionVocabulary.all.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()) {
                row.forEach { motion ->
                    val isSel = motion == selected
                    if (isSel) {
                        Button(onClick = { onSelect(motion) }, modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)) {
                            Text(shortName(motion), fontSize = 11.sp, maxLines = 1) }
                    } else {
                        OutlinedButton(onClick = { onSelect(motion) }, modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)) {
                            Text(shortName(motion), fontSize = 11.sp, maxLines = 1) }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

private fun shortName(motion: String) = when (motion) {
    "Low Kick" -> "Low K"; "Mid Kick" -> "Mid K"; "High Kick" -> "High K"
    "Front Kick" -> "Front K"; "Side Kick" -> "Side K"; else -> motion
}