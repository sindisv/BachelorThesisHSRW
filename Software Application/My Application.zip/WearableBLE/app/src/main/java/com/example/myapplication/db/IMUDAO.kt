package com.example.myapplication.db

import androidx.room.*

@Dao
interface ImuDao {

    // ── Insert ────────────────────────────────────────────────────────────────
    @Insert
    suspend fun insertAll(readings: List<ImuReading>)

    // ── Upload queue ──────────────────────────────────────────────────────────
    @Query("SELECT * FROM imu_readings WHERE sent = 0 ORDER BY id ASC LIMIT :batchSize")
    suspend fun getUnsentBatch(batchSize: Int = 500): List<ImuReading>

    @Query("UPDATE imu_readings SET sent = 1 WHERE id IN (:ids)")
    suspend fun markAsSent(ids: List<Long>)

    @Query("DELETE FROM imu_readings WHERE sent = 1")
    suspend fun deleteSent()

    @Query("SELECT COUNT(*) FROM imu_readings WHERE sent = 0")
    suspend fun unsentCount(): Int

    // ── Session queries ───────────────────────────────────────────────────────
    @Query("SELECT * FROM imu_readings WHERE sessionId = :sessionId ORDER BY id ASC")
    suspend fun getSessionReadings(sessionId: Long): List<ImuReading>


    @Query("SELECT COUNT(*) FROM imu_readings WHERE sessionId = :sessionId")
    suspend fun sessionRowCount(sessionId: Long): Int

    @Query("SELECT DISTINCT sessionId, sessionName, MIN(wallClockMs) as startMs, MAX(wallClockMs) as endMs, COUNT(*) as rowCount FROM imu_readings WHERE sessionId > 0 GROUP BY sessionId ORDER BY sessionId ASC")
    suspend fun getAllSessions(): List<SessionSummary>

    @Query("SELECT COALESCE(MAX(sessionId), 0) + 1 FROM imu_readings")
    suspend fun getNextSessionId(): Long

    // ── Device queries ────────────────────────────────────────────────────────
    // Count rows per device in current session
    @Query("SELECT COUNT(*) FROM imu_readings WHERE sessionId = :sessionId AND deviceId = :deviceId")
    suspend fun deviceRowCount(sessionId: Long, deviceId: Int): Int

    @Query("SELECT * FROM imu_readings WHERE sessionName = :name ORDER BY wallClockMs ASC")
    fun getSessionReadingsByName(name: String): List<ImuReading>

    // Get all rows for a specific device and session
    @Query("SELECT * FROM imu_readings WHERE sessionId = :sessionId AND deviceId = :deviceId ORDER BY id ASC")
    suspend fun getDeviceSessionReadings(sessionId: Long, deviceId: Int): List<ImuReading>
}