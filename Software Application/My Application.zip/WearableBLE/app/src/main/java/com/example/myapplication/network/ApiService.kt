package com.example.myapplication.network

import com.example.myapplication.db.ImuReading
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

// Defines the HTTP endpoints on the Raspberry Pi Flask server
// Reference: https://square.github.io/retrofit/

interface ApiService {

    // Health check — called first to verify Pi is reachable
    @GET("ping")
    suspend fun ping(): Response<Map<String, String>>

    // Main upload endpoint — sends a batch of IMU rows as JSON
    @POST("ingest")
    suspend fun ingest(@Body readings: List<ImuReading>): Response<Map<String, Any>>


    @POST("log_session")
    suspend fun logSession(@Body data: Map<String, String>): Response<Map<String, Any>>

    companion object {
        // Tailscale IP of Raspberry Pi — reachable from any network
        private const val BASE_URL = "http://100.81.213.4:5000/"

        fun create(): ApiService {
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService::class.java)
        }
    }
}
