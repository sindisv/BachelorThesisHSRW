package com.example.myapplication

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/**
 * A dialog that lists all recorded sessions so the user can pick one
 * to view the signal graph or run motion analysis on.
 *
 * Usage:
 *   SessionPickerDialog(
 *       sessions      = listOf("1a", "Jab_Left", ...),
 *       title         = "Pick a session to analyse",
 *       onSessionPick = { name -> ... },
 *       onDismiss     = { ... },
 *   )
 */
@Composable
fun SessionPickerDialog(
    sessions:      List<String>,
    title:         String,
    onSessionPick: (String) -> Unit,
    onDismiss:     () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape  = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
        ) {
            Column(modifier = Modifier.padding(20.dp)) {

                Text(title,
                    fontWeight = FontWeight.Bold,
                    fontSize   = 16.sp,
                    color      = Color(0xFF212121))

                Spacer(Modifier.height(4.dp))

                Text("${sessions.size} sessions recorded",
                    fontSize = 12.sp,
                    color    = Color(0xFF9E9E9E))

                Spacer(Modifier.height(12.dp))

                if (sessions.isEmpty()) {
                    Text("No sessions recorded yet.",
                        color    = Color(0xFF9E9E9E),
                        modifier = Modifier.padding(vertical = 16.dp))
                } else {
                    LazyColumn(
                        modifier              = Modifier.heightIn(max = 400.dp),
                        verticalArrangement   = Arrangement.spacedBy(4.dp),
                    ) {
                        items(sessions) { sessionName ->
                            SessionPickerItem(sessionName) {
                                onSessionPick(sessionName)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                OutlinedButton(
                    onClick  = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun SessionPickerItem(name: String, onClick: () -> Unit) {
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(name,
                fontWeight = FontWeight.Medium,
                fontSize   = 14.sp,
                color      = Color(0xFF212121))
        }
        Text("→",
            fontSize = 16.sp,
            color    = Color(0xFF2196F3))
    }
    HorizontalDivider(color = Color(0xFFF0F0F0))
}