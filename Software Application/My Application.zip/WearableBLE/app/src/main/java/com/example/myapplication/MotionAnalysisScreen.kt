package com.example.myapplication

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.LocalMotionClassifier.ClassificationResult
import com.example.myapplication.LocalMotionClassifier.MotionEvent
import com.example.myapplication.db.BLEDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ── Motion colours ────────────────────────────────────────────────────────────
private val MotionColours = mapOf(
    "Jab Left"          to Color(0xFF2196F3),
    "Jab Right"         to Color(0xFF1565C0),
    "Cross Left"        to Color(0xFF4CAF50),
    "Cross Right"       to Color(0xFF2E7D32),
    "Hook Left"         to Color(0xFFFF9800),
    "Hook Right"        to Color(0xFFE65100),
    "Uppercut Left"     to Color(0xFF9C27B0),
    "Uppercut Right"    to Color(0xFF6A1B9A),
    "Low Kick Left"     to Color(0xFFF44336),
    "Low Kick Right"    to Color(0xFFB71C1C),
    "Mid Kick Left"     to Color(0xFFE91E63),
    "Mid Kick Right"    to Color(0xFF880E4F),
    "High Kick Left"    to Color(0xFF00BCD4),
    "High Kick Right"   to Color(0xFF006064),
    "Front Kick Left"   to Color(0xFF8BC34A),
    "Front Kick Right"  to Color(0xFF33691E),
    "Side Kick Left"    to Color(0xFFFF5722),
    "Side Kick Right"   to Color(0xFFBF360C),
)
private fun motionColour(label: String) = MotionColours[label] ?: Color(0xFF9E9E9E)

private val DeviceNames = mapOf(
    1 to "Left Ankle", 2 to "Right Ankle",
    3 to "Left Wrist",  4 to "Right Wrist",
)

private sealed class AnalysisState {
    object Idle                         : AnalysisState()
    object Done                         : AnalysisState()
    data class Loading(val msg: String) : AnalysisState()
    data class Error  (val msg: String) : AnalysisState()
}

@Composable
fun MotionAnalysisScreen(
    sessionName: String,
    db:          BLEDatabase,
    onBack:      () -> Unit,
) {
    var state  by remember { mutableStateOf<AnalysisState>(AnalysisState.Idle) }
    var result by remember { mutableStateOf<ClassificationResult?>(null) }

    LaunchedEffect(sessionName) {
        state = AnalysisState.Loading("Loading session from database…")
        try {
            val readings = withContext(Dispatchers.IO) {
                db.imuDao().getSessionReadingsByName(sessionName)
            }
            if (readings.isEmpty()) {
                state = AnalysisState.Error("No data found for '$sessionName'")
                return@LaunchedEffect
            }
            state = AnalysisState.Loading("Analysing ${readings.size} rows…")
            val r = withContext(Dispatchers.Default) {
                LocalMotionClassifier.classify(readings)
            }
            result = r
            state  = AnalysisState.Done
        } catch (e: Exception) {
            state = AnalysisState.Error("Analysis failed: ${e.message}")
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5))) {
        // Top bar
        Surface(shadowElevation = 4.dp, color = Color(0xFF212121)) {
            Row(
                modifier          = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onBack) {
                    Text("← Back", color = Color.White, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("Motion Analysis",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(sessionName,
                        color = Color(0xFFBBBBBB), fontSize = 12.sp, maxLines = 1)
                }
            }
        }

        when (val s = state) {
            is AnalysisState.Idle    -> {}
            is AnalysisState.Loading -> LoadingPanel(s.msg)
            is AnalysisState.Error   -> ErrorPanel(s.msg, onBack)
            is AnalysisState.Done    -> result?.let { ResultPanel(it) }
        }
    }
}

@Composable
private fun LoadingPanel(message: String) {
    Column(
        modifier            = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CircularProgressIndicator(color = Color(0xFF2196F3), strokeWidth = 4.dp)
        Spacer(Modifier.height(20.dp))
        Text(message,
            color     = Color(0xFF555555),
            textAlign = TextAlign.Center,
            modifier  = Modifier.padding(horizontal = 32.dp))
    }
}

@Composable
private fun ErrorPanel(message: String, onBack: () -> Unit) {
    Column(
        modifier            = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("⚠", fontSize = 48.sp)
        Spacer(Modifier.height(12.dp))
        Text("Analysis failed", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Text(message, color = Color(0xFF757575), textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onBack) { Text("Go back") }
    }
}

@Composable
private fun ResultPanel(result: ClassificationResult) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // Stats header
        Card(modifier = Modifier.fillMaxWidth(),
            colors   = CardDefaults.cardColors(containerColor = Color(0xFF212121)),
            shape    = RoundedCornerShape(12.dp)) {
            Row(modifier              = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly) {
                StatItem("Events",   "${result.totalEvents}", Color.White)
                StatItem("Duration", "${result.durationSec.toInt()}s", Color.White)
                StatItem("Types",    "${result.summary.size}", Color.White)
            }
        }

        // Motion bar chart
        SectionTitle("Detected Motions")
        Card(modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(12.dp),
            colors   = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier             = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (result.summary.isEmpty()) {
                    Text("No motion events detected",
                        color = Color(0xFF9E9E9E), modifier = Modifier.padding(8.dp))
                } else {
                    val maxCount = result.summary.values.maxOrNull() ?: 1
                    result.summary.entries
                        .sortedByDescending { it.value }
                        .forEach { (motion, count) -> MotionBar(motion, count, maxCount) }
                }
            }
        }

        // Timeline
        SectionTitle("Motion Timeline")
        Card(modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(12.dp),
            colors   = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Each dot = one detected event  ·  dot size = model confidence",
                    fontSize = 11.sp, color = Color(0xFF9E9E9E))
                Spacer(Modifier.height(10.dp))
                if (result.events.isNotEmpty()) {
                    TimelineView(result.events, result.durationSec)
                } else {
                    Text("No events to display",
                        color    = Color(0xFF9E9E9E),
                        modifier = Modifier.padding(8.dp))
                }
            }
        }

        // Legend
        val usedLabels = result.events.map { it.prediction }.distinct().sorted()
        if (usedLabels.isNotEmpty()) {
            SectionTitle("Legend")
            Card(modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(12.dp),
                colors   = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier             = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    usedLabels.chunked(2).forEach { row ->
                        Row(modifier              = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { label ->
                                Row(verticalAlignment = Alignment.CenterVertically,
                                    modifier          = Modifier.weight(1f)) {
                                    Box(modifier = Modifier.size(12.dp).clip(CircleShape)
                                        .background(motionColour(label)))
                                    Spacer(Modifier.width(6.dp))
                                    Text(label, fontSize = 11.sp, color = Color(0xFF333333))
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // Event list
        SectionTitle("All Events (${result.events.size})")
        Card(modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(12.dp),
            colors   = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier.padding(8.dp)) {
                EventRowHeader()
                HorizontalDivider()
                result.events.forEach { event ->
                    EventRow(event)
                    HorizontalDivider(color = Color(0xFFF0F0F0))
                }
            }
        }

        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun TimelineView(events: List<MotionEvent>, durationSec: Float) {
    val deviceIds = listOf(1, 2, 3, 4)
    val rowH      = 40.dp
    val labelW    = 90.dp

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(rowH * deviceIds.size + 28.dp)
    ) {
        val totalW = maxWidth

        // Row labels and track lines
        deviceIds.forEachIndexed { idx, devId ->
            Box(modifier = Modifier
                .offset(x = 0.dp, y = rowH * idx + 8.dp)
                .width(labelW).height(rowH),
                contentAlignment = Alignment.CenterStart) {
                Text(DeviceNames[devId] ?: "D$devId",
                    fontSize = 9.sp, color = Color(0xFF888888))
            }
            Box(modifier = Modifier
                .offset(x = labelW, y = rowH * idx + rowH / 2 - 0.5.dp)
                .width(totalW - labelW).height(1.dp)
                .background(Color(0xFFEEEEEE)))
        }

        // Event dots
        events.forEach { event ->
            val devIdx = deviceIds.indexOf(event.deviceId)
            if (devIdx < 0) return@forEach
            val frac    = if (durationSec > 0f)
                (event.timeSec / durationSec).coerceIn(0f, 1f) else 0f
            val dotSize = (10 + event.confidence * 16).dp
            val xOff    = labelW + (totalW - labelW) * frac - dotSize / 2
            val yOff    = rowH * devIdx + rowH / 2 - dotSize / 2
            Box(modifier = Modifier
                .offset(x = xOff, y = yOff)
                .size(dotSize).clip(CircleShape)
                .background(motionColour(event.prediction).copy(alpha = 0.85f)))
        }

        // Time axis labels
        listOf(0f, 0.25f, 0.5f, 0.75f, 1f).forEach { frac ->
            val xOff = labelW + (totalW - labelW) * frac - 16.dp
            Box(modifier = Modifier
                .offset(x = xOff, y = rowH * deviceIds.size + 4.dp)
                .width(32.dp),
                contentAlignment = Alignment.Center) {
                Text("${(durationSec * frac).toInt()}s",
                    fontSize  = 9.sp,
                    color     = Color(0xFFAAAAAA),
                    textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun MotionBar(motion: String, count: Int, maxCount: Int) {
    val frac = count.toFloat() / maxCount.toFloat()
    Column {
        Row(modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape)
                    .background(motionColour(motion)))
                Spacer(Modifier.width(6.dp))
                Text(motion, fontSize = 12.sp, color = Color(0xFF333333))
            }
            Text("$count",
                fontWeight = FontWeight.Bold,
                fontSize   = 13.sp,
                color      = motionColour(motion))
        }
        Spacer(Modifier.height(3.dp))
        Box(modifier = Modifier.fillMaxWidth().height(6.dp)
            .clip(RoundedCornerShape(3.dp)).background(Color(0xFFF0F0F0))) {
            Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(frac)
                .clip(RoundedCornerShape(3.dp)).background(motionColour(motion)))
        }
    }
}

@Composable
private fun EventRowHeader() {
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text("Time",   fontWeight = FontWeight.Bold, fontSize = 11.sp,
            color = Color(0xFF666666), modifier = Modifier.width(48.dp))
        Text("Sensor", fontWeight = FontWeight.Bold, fontSize = 11.sp,
            color = Color(0xFF666666), modifier = Modifier.width(90.dp))
        Text("Motion", fontWeight = FontWeight.Bold, fontSize = 11.sp,
            color = Color(0xFF666666), modifier = Modifier.weight(1f))
        Text("Conf",   fontWeight = FontWeight.Bold, fontSize = 11.sp,
            color = Color(0xFF666666), modifier = Modifier.width(40.dp),
            textAlign = TextAlign.End)
    }
}

@Composable
private fun EventRow(event: MotionEvent) {
    Row(modifier          = Modifier.fillMaxWidth()
        .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text("${event.timeSec.toInt()}s",
            fontSize = 11.sp, color = Color(0xFF777777),
            modifier = Modifier.width(48.dp))
        Text(event.location,
            fontSize = 11.sp, color = Color(0xFF555555),
            modifier = Modifier.width(90.dp))
        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape)
                .background(motionColour(event.prediction)))
            Spacer(Modifier.width(5.dp))
            Text(event.prediction, fontSize = 11.sp,
                fontWeight = FontWeight.Medium, color = Color(0xFF212121))
        }
        Text("${(event.confidence * 100).toInt()}%",
            fontSize   = 11.sp, fontWeight = FontWeight.Bold,
            color      = motionColour(event.prediction),
            modifier   = Modifier.width(40.dp),
            textAlign  = TextAlign.End)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF212121))
}

@Composable
private fun StatItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = color)
        Text(label, fontSize = 11.sp, color = color.copy(alpha = 0.7f))
    }
}