package com.example.myapplication.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "imu_readings")
data class ImuReading(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    // Session tracking
    val sessionId: Long = 0,
    val sessionName: String = "",

    // Device tracking — which sensor sent this reading
    val deviceId: Int = 0,           // 1=BNO055, 2=SensePlus_2, 3=SensePlus_3, 4=SensePlus_4
    val bodyLocation: String = "",   // "dominant_wrist", "nondominant_wrist", "dominant_ankle", "dominant_shin"

    // Timestamps
    val deviceTimestampMs: Long,
    val wallClockMs: Long,

    // Accelerometer (m/s²)
    val accelX: Float,
    val accelY: Float,
    val accelZ: Float,

    // Gyroscope (deg/s)
    val gyroX: Float,
    val gyroY: Float,
    val gyroZ: Float,

    // Orientation
    // Device 1 (BNO055): quatW, quatX, quatY, quatZ = real quaternion
    // Devices 2-4 (Sense Plus): quatW=roll, quatX=pitch, quatY=yaw, quatZ=0
    val quatW: Float,
    val quatX: Float,
    val quatY: Float,
    val quatZ: Float,

    val sent: Boolean = false
)