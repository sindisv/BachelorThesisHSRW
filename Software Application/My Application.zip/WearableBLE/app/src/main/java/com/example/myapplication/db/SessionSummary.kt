package com.example.myapplication.db

import androidx.room.ColumnInfo

// Returned by getAllSessions() query
// Summarises each session for display in the session list
data class SessionSummary(
    val sessionId: Long,
    val sessionName: String,
    @ColumnInfo(name = "startMs") val startMs: Long,
    @ColumnInfo(name = "endMs") val endMs: Long,
    @ColumnInfo(name = "rowCount") val rowCount: Int
)