package com.example.myapplication

import com.example.myapplication.LocalMotionClassifier.MotionEvent

/**
 * SequenceAligner
 * ===============
 * Maps a user-entered PerformedSequence (ground truth) onto detected events,
 * producing labelled training data.
 *
 * A punch is ONE segment (windup -> impact -> retraction), not two events;
 * surplus peaks beyond the expected count are treated as retraction/non-strike.
 *
 * Modes:
 *   WHOLE_SESSION_ONE_MOTION -> every detected strike is that one motion
 *       (the "I did only jabs the whole time" case). Cleanest labels.
 *   STRUCTURED single-type blocks -> label all events in each block by type.
 *   STRUCTURED mixed combos -> positional alignment + retraction suppression.
 *   FREE_ROUND / FREE_TEXT -> stored as context, not aligned.
 */
object SequenceAligner {

    data class LabelledEvent(
        val event:     MotionEvent,
        val trueLabel: String,
        val isStrike:  Boolean,
        val aligned:   Boolean,
    )

    data class AlignmentResult(
        val labelled:        List<LabelledEvent>,
        val expectedCount:   Int,
        val detectedCount:   Int,
        val strikeCount:     Int,
        val retractionCount: Int,
        val countsMatch:     Boolean,
        val note:            String,
    )

    fun align(events: List<MotionEvent>, sequence: PerformedSequence): AlignmentResult {
        val sorted = events.sortedBy { it.timeSec }

        return when (sequence.mode) {
            SequenceMode.WHOLE_SESSION_ONE_MOTION ->
                alignWholeSession(sorted, sequence.wholeSessionMotion)
            SequenceMode.FREE_ROUND, SequenceMode.FREE_TEXT ->
                AlignmentResult(
                    sorted.map { LabelledEvent(it, "Unknown", true, false) },
                    0, sorted.size, sorted.size, 0, false,
                    "Free round / text — stored as context, not aligned.")
            SequenceMode.STRUCTURED -> alignStructured(sorted, sequence)
        }
    }

    // ── Whole session = one motion ──────────────────────────────────────────────
    private fun alignWholeSession(
        events: List<MotionEvent>,
        motion: String,
    ): AlignmentResult {
        if (motion.isBlank()) {
            return AlignmentResult(
                events.map { LabelledEvent(it, "Unknown", true, false) },
                0, events.size, events.size, 0, false,
                "Whole-session motion not specified.")
        }
        val labelled = events.map { ev ->
            LabelledEvent(ev, "$motion ${ev.side}", true, true)
        }
        return AlignmentResult(
            labelled, events.size, events.size, events.size, 0, true,
            "Whole session labelled as '$motion' (${events.size} strikes).")
    }

    // ── Structured ──────────────────────────────────────────────────────────────
    private fun alignStructured(
        events: List<MotionEvent>,
        sequence: PerformedSequence,
    ): AlignmentResult {
        val expected = sequence.flattenExpected()

        if (sequence.hasUnknownCount()) {
            val pattern = sequence.entries.flatMap { it.motions }
            if (pattern.isEmpty() || events.isEmpty()) {
                return AlignmentResult(
                    events.map { LabelledEvent(it, "Unknown", true, false) },
                    0, events.size, events.size, 0, false,
                    "Unknown count and no pattern — stored unaligned.")
            }
            val labelled = events.mapIndexed { i, ev ->
                LabelledEvent(ev, "${pattern[i % pattern.size]} ${ev.side}", true, false)
            }
            return AlignmentResult(
                labelled, 0, events.size, events.size, 0, false,
                "Unknown count: pattern (${pattern.joinToString("-")}) repeated, provisional.")
        }

        val singleType = sequence.entries.all { it.motions.size == 1 }
        return if (singleType) alignBlocks(events, sequence)
        else alignPositional(events, expected)
    }

    private fun alignBlocks(
        events: List<MotionEvent>,
        sequence: PerformedSequence,
    ): AlignmentResult {
        val blocks = sequence.entries.map { it.motions.first() to it.repeat }
        val totalExpected = blocks.sumOf { it.second }
        if (events.isEmpty()) {
            return AlignmentResult(emptyList(), totalExpected, 0, 0, 0, false,
                "No events detected.")
        }
        val perBlockShare = events.size.toFloat() / blocks.size
        val labelled = events.mapIndexed { i, ev ->
            val blockIdx = (i / perBlockShare).toInt().coerceIn(0, blocks.size - 1)
            LabelledEvent(ev, "${blocks[blockIdx].first} ${ev.side}", true, true)
        }
        val match = events.size == totalExpected
        return AlignmentResult(
            labelled, totalExpected, events.size, labelled.size, 0, match,
            if (match) "Block labelling: count matches ($totalExpected)."
            else "Block labelling: detected ${events.size} vs expected $totalExpected.")
    }

    private fun alignPositional(
        events: List<MotionEvent>,
        expected: List<String>,
    ): AlignmentResult {
        val (strikes, retractions) = separateRetractions(events, expected.size)
        val labelled = mutableListOf<LabelledEvent>()
        retractions.forEach { labelled.add(LabelledEvent(it, "Retraction", false, false)) }
        val n = minOf(strikes.size, expected.size)
        for (i in 0 until n) {
            val ev = strikes[i]
            labelled.add(LabelledEvent(ev, "${expected[i]} ${ev.side}", true, true))
        }
        for (i in n until strikes.size) {
            labelled.add(LabelledEvent(strikes[i], "Unknown", true, false))
        }
        labelled.sortBy { it.event.timeSec }
        val match = strikes.size == expected.size
        return AlignmentResult(
            labelled, expected.size, strikes.size + retractions.size,
            strikes.size, retractions.size, match,
            if (match) "Positional: ${strikes.size} strikes matched, ${retractions.size} retractions suppressed."
            else "Positional: ${strikes.size} strikes vs ${expected.size} expected — REVIEW.")
    }

    private fun separateRetractions(
        events: List<MotionEvent>,
        expectedCount: Int,
    ): Pair<List<MotionEvent>, List<MotionEvent>> {
        if (expectedCount <= 0 || events.size <= expectedCount) return events to emptyList()
        val surplus = events.size - expectedCount
        val scored = events.mapIndexed { i, ev ->
            val prev = if (i > 0) events[i - 1] else null
            val gap  = if (prev != null) ev.timeSec - prev.timeSec else 99f
            val smaller = prev != null && ev.peakMag < prev.peakMag
            val score = (if (gap < 0.6f) (0.6f - gap) else 0f) + (if (smaller) 0.3f else 0f)
            i to score
        }
        val retractionIdx = scored.sortedByDescending { it.second }
            .take(surplus).map { it.first }.toSet()
        return events.filterIndexed { i, _ -> i !in retractionIdx } to
                events.filterIndexed { i, _ -> i in retractionIdx }
    }
}