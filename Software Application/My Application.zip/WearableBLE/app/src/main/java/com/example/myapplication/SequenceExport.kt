package com.example.myapplication

import android.os.Environment
import com.example.myapplication.db.ImuReading
import java.io.File
import java.io.FileWriter

/**
 * Export helpers.
 *
 * KEEPS the existing IMU CSV exactly as before (same columns, same format),
 * and ADDS:
 *   1. extra metadata rows at the top of a companion sequence file describing
 *      the performed sequence and rep counts
 *   2. a per-event labels CSV produced by aligning the sequence to detected
 *      events (the ground-truth training labels)
 *
 * The main IMU CSV is unchanged so all existing analysis scripts still work.
 */
object SequenceExport {

    /**
     * Write the companion sequence description file for a session.
     * Filename: <session>__sequence.txt
     */
    fun exportSequenceNote(
        sessionName: String,
        sequence:    PerformedSequence,
    ): File {
        val dir = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val safe = sessionName.replace(" ", "_")
        val file = File(dir, "${safe}__sequence.txt")
        FileWriter(file).use { w ->
            w.append("session_name: $sessionName\n")
            w.append("sequence_mode: ${sequence.mode.name}\n")
            w.append("sequence_description: ${sequence.describe()}\n")
            w.append("count_known: ${!sequence.hasUnknownCount()}\n")
            if (sequence.freeText.isNotBlank()) {
                w.append("free_text: ${sequence.freeText}\n")
            }
            when (sequence.mode) {
                SequenceMode.WHOLE_SESSION_ONE_MOTION -> {
                    w.append("whole_session_motion: ${sequence.wholeSessionMotion}\n")
                    w.append("note: every detected strike labelled as this motion\n")
                }
                SequenceMode.STRUCTURED -> {
                    w.append("\n# Structured entries (motion(s), repeat, count_known)\n")
                    sequence.entries.forEach { e ->
                        w.append("entry: ${e.motions.joinToString("-")}, " +
                                "repeat=${if (e.countKnown) e.repeat.toString() else "unknown"}\n")
                    }
                    if (!sequence.hasUnknownCount()) {
                        w.append("\ntotal_expected_strikes: ${sequence.flattenExpected().size}\n")
                    }
                }
                SequenceMode.FREE_ROUND, SequenceMode.FREE_TEXT -> {
                    w.append("note: unstructured — stored as context, not aligned\n")
                }
            }
        }
        return file
    }

    /**
     * Write the per-event ground-truth label CSV by aligning the sequence
     * to the detected events. One row per detected event.
     * Filename: <session>__labels.csv
     *
     * Columns:
     *   time_s, device_id, location, side, detected_prediction, detected_conf,
     *   peak_mag, true_label, is_strike, aligned
     *
     * This is the file the retraining script reads as ground truth.
     */
    fun exportLabels(
        sessionName: String,
        readings:    List<ImuReading>,
        sequence:    PerformedSequence,
    ): File {
        val dir = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val safe = sessionName.replace(" ", "_")
        val file = File(dir, "${safe}__labels.csv")

        // Run the classifier to get detected events, then align to the sequence
        val result = LocalMotionClassifier.classify(readings)

        FileWriter(file).use { w ->
            w.append("session_name,sequence_description\n")
            w.append("$sessionName,\"${sequence.describe()}\"\n\n")
            w.append("time_s,device_id,location,side,detected_prediction," +
                    "detected_conf,peak_mag,true_label,is_strike,aligned\n")

            // Align per device (each limb has its own event stream + side)
            val byDevice = result.events.groupBy { it.deviceId }
            for ((_, devEvents) in byDevice) {
                val alignment = SequenceAligner.align(devEvents, sequence)
                alignment.labelled.sortedBy { it.event.timeSec }.forEach { le ->
                    val e = le.event
                    w.append("${e.timeSec},${e.deviceId},\"${e.location}\",${e.side}," +
                            "\"${e.prediction}\",${e.confidence},${e.peakMag}," +
                            "\"${le.trueLabel}\",${le.isStrike},${le.aligned}\n")
                }
            }
        }
        return file
    }

    /**
     * Convenience: export everything for a session in one go —
     * the standard IMU CSV (unchanged format), the sequence note, and the labels.
     * Returns the list of files created.
     */
    fun exportSessionWithSequence(
        sessionName: String,
        readings:    List<ImuReading>,
        sequence:    PerformedSequence?,
    ): List<File> {
        val files = mutableListOf<File>()

        // 1. Standard IMU CSV — UNCHANGED format (same as existing export)
        val dir = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val safe = sessionName.replace(" ", "_")
        val imuFile = File(dir, "$safe.csv")
        FileWriter(imuFile).use { w ->
            w.append("session_name,device_id,body_location,device_ts_ms," +
                    "wall_clock_ms,accel_x,accel_y,accel_z," +
                    "gyro_x,gyro_y,gyro_z,quat_w,quat_x,quat_y,quat_z\n")
            for (r in readings) {
                w.append("${r.sessionName},${r.deviceId},${r.bodyLocation}," +
                        "${r.deviceTimestampMs},${r.wallClockMs}," +
                        "${r.accelX},${r.accelY},${r.accelZ}," +
                        "${r.gyroX},${r.gyroY},${r.gyroZ}," +
                        "${r.quatW},${r.quatX},${r.quatY},${r.quatZ}\n")
            }
        }
        files.add(imuFile)

        // 2 & 3. Sequence note + labels — only if a sequence was entered
        if (sequence != null) {
            files.add(exportSequenceNote(sessionName, sequence))
            files.add(exportLabels(sessionName, readings, sequence))
        }
        return files
    }
}