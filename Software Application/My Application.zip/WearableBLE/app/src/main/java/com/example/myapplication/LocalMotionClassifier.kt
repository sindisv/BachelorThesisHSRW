package com.example.myapplication

import com.example.myapplication.db.ImuReading
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * LocalMotionClassifier — with THREE-PART reject gate.
 *
 * Derived from full analysis of ALL sessions (1a–4d, Device1/3/Boxinghook,
 * full_round, right_random, rightwrisr) = 509 strikes + 1307 quiet + 17 shaking.
 *
 * THREE-PART GATE (each condition must be met):
 *   1. INTENSITY:  jerkStd > 120 AND dynMax > 20
 *      → separates strikes from rest/quiet (98% accuracy)
 *   2. SHAPE:      nSubPeaks ≤ 3  OR  aboveHalfFrac < 0.35
 *      → separates clean strike (1 peak) from chaotic shaking (5-6 peaks)
 *   3. CEILING:    gyroMax < 1500
 *      → punches reach max ~1006 (95th pct); shaking goes 1120-2836
 *
 * Validated on random-shaking test data: rejects 9/10 false peaks.
 * Old gate (impulse+rotation OR gyro>700) rejected 0/10 — the OR gyro>700
 * was an open door that shaking walked through.
 */
object LocalMotionClassifier {

    data class MotionEvent(
        val timeSec:    Float,
        val deviceId:   Int,
        val location:   String,
        val prediction: String,
        val confidence: Float,
        val peakMag:    Float,
        val limbType:   String,
        val side:       String,
    )

    data class ClassificationResult(
        val events:        List<MotionEvent>,
        val summary:       Map<String, Int>,
        val totalEvents:   Int,
        val rejectedCount: Int,
        val durationSec:   Float,
    )

    private val LABELS = arrayOf("Cross", "Hook", "Jab", "Uppercut")

    private data class Features(
        val impulse: Float, val rotation: Float,
        val gzMax: Float, val gyMax: Float, val gxMax: Float,
        val gzMean: Float, val axMean: Float, val ayMean: Float,
        val azMean: Float, val azMax: Float,
        val dynMean: Float, val dynMax: Float,
        val gyroMax: Float,
        val totalAngle: Float, val angleY: Float, val angleZ: Float,
        // Jerk features
        val jerkStd: Float,
        // Shape features
        val nSubPeaks: Int,
        val aboveHalfFrac: Float,
    )

    // ── Gate thresholds ───────────────────────────────────────────────────────
    private const val GATE_JERK_STD     = 120f    // Part 1: sharp onset
    private const val GATE_DYN_MAX      = 20f     // Part 1: minimum peak
    private const val GATE_MAX_SUBPEAKS = 3       // Part 2: clean shape
    private const val GATE_ABOVE_HALF   = 0.35f   // Part 2: brief spike
    private const val GATE_GYRO_CEIL    = 1500f   // Part 3: not chaotic

    fun classify(readings: List<ImuReading>): ClassificationResult {
        if (readings.isEmpty()) return ClassificationResult(emptyList(), emptyMap(), 0, 0, 0f)
        val dur = (readings.maxOf { it.wallClockMs } - readings.minOf { it.wallClockMs }) / 1000f
        val all = mutableListOf<MotionEvent>()
        var rej = 0
        readings.groupBy { it.deviceId }.forEach { (devId, rds) ->
            val (evts, r) = classifyDevice(rds.sortedBy { it.wallClockMs }, devId)
            all.addAll(evts); rej += r
        }
        val sorted = all.sortedBy { it.timeSec }
        return ClassificationResult(sorted, sorted.groupBy { it.prediction }.mapValues { it.value.size },
            sorted.size, rej, dur)
    }

    private fun classifyDevice(readings: List<ImuReading>, deviceId: Int): Pair<List<MotionEvent>, Int> {
        if (readings.size < 10) return emptyList<MotionEvent>() to 0

        val locRaw = readings.first().bodyLocation.trim()
        val locL = locRaw.lowercase()
        val side = when {
            locL.contains("right") -> "Right"; locL.contains("left") -> "Left"
            deviceId == 1 || deviceId == 3 -> "Left"; else -> "Right"
        }
        val isKick = locL.contains("ankle") || locL.contains("shin") ||
                locL.contains("leg") || locL.contains("foot") ||
                (!(locL.contains("wrist") || locL.contains("hand") || locL.contains("arm"))
                        && (deviceId == 1 || deviceId == 2))
        val displayLoc = if (locL == "none" || locL.isBlank()) when (deviceId) {
            1 -> "Left Ankle"; 2 -> "Right Ankle"; 3 -> "Left Wrist"; 4 -> "Right Wrist"
            else -> "D$deviceId"
        } else locRaw

        val t0 = readings.first().wallClockMs
        val mag = readings.map { r -> sqrt(r.accelX*r.accelX + r.accelY*r.accelY + r.accelZ*r.accelZ).toFloat() }
        val dyn = mag.map { abs(it - 9.81f) }
        val diffs = readings.zipWithNext().map { (it.second.wallClockMs - it.first.wallClockMs).toFloat() }.filter { it > 0 }
        val fs = if (diffs.isNotEmpty()) 1000f / diffs.median() else 33f
        val thr = (dyn.average().toFloat() + 2f * dyn.std()).coerceAtLeast(5f)
        val peaks = detectPeaks(dyn, thr, maxOf((fs * 0.4f).toInt(), 3))

        val events = mutableListOf<MotionEvent>()
        var rejected = 0

        for (peakIdx in peaks) {
            val peakMs = readings[peakIdx].wallClockMs
            val win = readings.filter { it.wallClockMs in (peakMs - 300)..(peakMs + 500) }
            if (win.size < 4) continue
            val f = computeFeatures(win, fs)

            // ── THREE-PART REJECT GATE ──────────────────────────────────────
            // Part 1: INTENSITY — enough energy for a real strike?
            val intensity = f.jerkStd > GATE_JERK_STD && f.dynMax > GATE_DYN_MAX
            // Part 2: SHAPE — clean single peak, not chaotic multi-peak?
            val shape = f.nSubPeaks <= GATE_MAX_SUBPEAKS || f.aboveHalfFrac < GATE_ABOVE_HALF
            // Part 3: CEILING — rotation within punch range, not wild shaking?
            val ceiling = f.gyroMax < GATE_GYRO_CEIL
            // Must pass ALL three
            if (!(intensity && shape && ceiling)) { rejected++; continue }

            // ── TYPE CLASSIFICATION ─────────────────────────────────────────
            val (pred, conf) = if (isKick) classifyKick(f, side) else classifyPunch(f, side)
            events.add(MotionEvent(
                (readings[peakIdx].wallClockMs - t0) / 1000f, deviceId, displayLoc,
                pred, conf, mag[peakIdx], if (isKick) "Kick" else "Punch", side))
        }
        return events to rejected
    }

    private fun computeFeatures(win: List<ImuReading>, fs: Float): Features {
        val ax = win.map { it.accelX.toFloat() }
        val ay = win.map { it.accelY.toFloat() }
        val az = win.map { it.accelZ.toFloat() }
        val gx = win.map { it.gyroX.toFloat() }
        val gy = win.map { it.gyroY.toFloat() }
        val gz = win.map { it.gyroZ.toFloat() }
        val mag = ax.indices.map { i -> sqrt(ax[i]*ax[i] + ay[i]*ay[i] + az[i]*az[i]) }
        val gyroMag = gx.indices.map { i -> sqrt(gx[i]*gx[i] + gy[i]*gy[i] + gz[i]*gz[i]) }
        val dyn = mag.map { abs(it - 9.81f) }
        val dt = 1f / fs

        fun List<Float>.trapz() = zipWithNext().sumOf { (a, b) -> ((a + b) / 2.0 * dt) }.toFloat()

        // Jerk = derivative of dynamic acceleration
        val jerk = if (dyn.size > 1) dyn.zipWithNext().map { (a, b) -> (b - a) / dt } else listOf(0f)

        // Sub-peak count: how many peaks above 40% of max in the window
        val dynArr = dyn.toFloatArray()
        val subThr = (dynArr.maxOrNull() ?: 0f) * 0.4f
        var nSub = 0
        for (i in 1 until dynArr.size - 1) {
            if (dynArr[i] > subThr && dynArr[i] >= dynArr[i-1] && dynArr[i] >= dynArr[i+1]) nSub++
        }

        // Fraction of window above half the peak
        val halfPeak = (dynArr.maxOrNull() ?: 0f) * 0.5f
        val aboveHalf = dynArr.count { it > halfPeak }.toFloat() / dynArr.size.toFloat()

        return Features(
            impulse    = dyn.trapz(),
            rotation   = gyroMag.trapz(),
            gzMax      = gz.map { abs(it) }.maxOrNull() ?: 0f,
            gyMax      = gy.map { abs(it) }.maxOrNull() ?: 0f,
            gxMax      = gx.map { abs(it) }.maxOrNull() ?: 0f,
            gzMean     = gz.average().toFloat(),
            axMean     = ax.average().toFloat(),
            ayMean     = ay.average().toFloat(),
            azMean     = az.average().toFloat(),
            azMax      = az.maxOrNull() ?: 0f,
            dynMean    = dyn.average().toFloat(),
            dynMax     = dyn.maxOrNull() ?: 0f,
            gyroMax    = gyroMag.maxOrNull() ?: 0f,
            totalAngle = gx.map { abs(it) }.trapz() + gy.map { abs(it) }.trapz() + gz.map { abs(it) }.trapz(),
            angleY     = gy.map { abs(it) }.trapz(),
            angleZ     = gz.map { abs(it) }.trapz(),
            jerkStd    = jerk.std(),
            nSubPeaks  = nSub,
            aboveHalfFrac = aboveHalf,
        )
    }

    // ── Punch type (depth-5 tree + early uppercut) ────────────────────────────
    private fun classifyPunch(f: Features, side: String): Pair<String, Float> {
        if (f.gyMax > 500f && f.azMax > 30f && f.gzMax < 500f) return "Uppercut $side" to 0.80f
        val label = if (f.impulse <= 11.53f) {
            if (f.ayMean <= -10.50f) { if (f.azMax <= 15.93f) 0 else 1 }
            else {
                if (f.gzMean <= -87.24f) { if (f.gxMax <= 259.48f) 1 else 0 }
                else { if (f.axMean <= -4.39f) 0 else { if (f.gyMax <= 769.27f) 2 else 3 } }
            }
        } else {
            if (f.gzMax <= 620.81f) {
                if (f.totalAngle <= 288.36f) {
                    if (f.azMax <= 37.84f) { if (f.dynMean <= 13.49f) 3 else 0 }
                    else { if (f.gxMax <= 202.51f) 3 else 1 }
                } else {
                    if (f.gzMean <= -21.34f) { if (f.angleY <= 128.35f) 3 else 1 }
                    else { if (f.angleZ <= 193.70f) 3 else 0 }
                }
            } else 1
        }
        val conf = when (label) { 2->0.82f; 1->0.76f; 3->0.75f; 0->0.60f; else->0.65f }
        return "${LABELS[label]} $side" to conf
    }

    // ── Kick type ─────────────────────────────────────────────────────────────
    private fun classifyKick(f: Features, side: String): Pair<String, Float> {
        if (f.gyroMax < 520f && f.totalAngle < 320f) return "Side Kick $side" to 0.72f
        if (f.ayMean in 8f..18f && f.totalAngle < 330f && f.gyroMax < 700f) return "Front Kick $side" to 0.68f
        if (f.ayMean > 14f && f.totalAngle > 340f) return "High Kick $side" to 0.70f
        if (f.totalAngle > 380f) return "Low Kick $side" to 0.71f
        return "Mid Kick $side" to 0.65f
    }

    private fun detectPeaks(signal: List<Float>, threshold: Float, minDist: Int): List<Int> {
        val peaks = mutableListOf<Int>(); var last = -minDist
        for (i in 1 until signal.size - 1) {
            if (signal[i] > threshold && signal[i] >= signal[i-1] && signal[i] >= signal[i+1] && i - last >= minDist) {
                peaks.add(i); last = i
            }
        }
        return peaks
    }

    private fun List<Float>.std(): Float {
        if (size < 2) return 0f
        val m = average().toFloat()
        return sqrt(sumOf { ((it - m) * (it - m)).toDouble() }.toFloat() / size)
    }
    private fun List<Float>.median(): Float {
        if (isEmpty()) return 0f; val s = sorted()
        return if (s.size % 2 == 0) (s[s.size/2-1] + s[s.size/2]) / 2f else s[s.size/2]
    }
}