package com.example.myapplication

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import com.example.myapplication.LocalMotionClassifier.ClassificationResult
import com.example.myapplication.LocalMotionClassifier.MotionEvent
import com.example.myapplication.db.BLEDatabase
import com.example.myapplication.db.ImuReading
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.sqrt

// ── Motion colours ────────────────────────────────────────────────────────────
private val MotionColours = mapOf(
    "Jab Left"          to Color(0xFF2196F3),
    "Jab Right"         to Color(0xFF1565C0),
    "Cross Left"        to Color(0xFF4CAF50),
    "Cross Right"       to Color(0xFF2E7D32),
    "Hook Left"         to Color(0xFFFF9800),
    "Hook Right"        to Color(0xFFE65100),
    "Uppercut Left"     to Color(0xFF9C27B0),
    "Uppercut Right"    to Color(0xFF6A1B9A),
    "Low Kick Left"     to Color(0xFFF44336),
    "Low Kick Right"    to Color(0xFFB71C1C),
    "Mid Kick Left"     to Color(0xFFE91E63),
    "Mid Kick Right"    to Color(0xFF880E4F),
    "High Kick Left"    to Color(0xFF00BCD4),
    "High Kick Right"   to Color(0xFF006064),
    "Front Kick Left"   to Color(0xFF8BC34A),
    "Front Kick Right"  to Color(0xFF33691E),
    "Side Kick Left"    to Color(0xFFFF5722),
    "Side Kick Right"   to Color(0xFFBF360C),
)
private fun motionColour(label: String) = MotionColours[label] ?: Color(0xFF9E9E9E)

// ── Device colours (matching rest of app) ────────────────────────────────────
private val DeviceColours = mapOf(
    1 to Color(0xFF2196F3),
    2 to Color(0xFF4CAF50),
    3 to Color(0xFFFF9800),
    4 to Color(0xFFE53935),
)
private val DeviceNames = mapOf(
    1 to "Left Ankle", 2 to "Right Ankle",
    3 to "Left Wrist",  4 to "Right Wrist",
)

// ── State ─────────────────────────────────────────────────────────────────────
private sealed class ScreenState {
    object Idle                         : ScreenState()
    object Done                         : ScreenState()
    data class Loading(val msg: String) : ScreenState()
    data class Error  (val msg: String) : ScreenState()
}

// ── Data per device ───────────────────────────────────────────────────────────
private data class DeviceSignal(
    val deviceId: Int,
    val times:    List<Float>,     // seconds from session start
    val accelMag: List<Float>,     // |a| m/s²
    val dynamic:  List<Float>,     // ||a| - 9.81|
    val gyroMag:  List<Float>,     // |ω| deg/s
    val accelX:   List<Float>,
    val accelY:   List<Float>,
    val accelZ:   List<Float>,
    val gyroX:    List<Float>,
    val gyroY:    List<Float>,
    val gyroZ:    List<Float>,
    val location: String,
    val fs:       Float,
    val durationSec: Float,
)

// ── Screen ────────────────────────────────────────────────────────────────────
@Composable
fun SessionAnalysisScreen(
    sessionName: String,
    db:          BLEDatabase,
    onBack:      () -> Unit,
) {
    var state        by remember { mutableStateOf<ScreenState>(ScreenState.Idle) }
    var signals      by remember { mutableStateOf<List<DeviceSignal>>(emptyList()) }
    var classResult  by remember { mutableStateOf<ClassificationResult?>(null) }
    var allReadings  by remember { mutableStateOf<List<ImuReading>>(emptyList()) }

    LaunchedEffect(sessionName) {
        state = ScreenState.Loading("Loading session…")
        try {
            val readings = withContext(Dispatchers.IO) {
                db.imuDao().getSessionReadingsByName(sessionName)
            }
            if (readings.isEmpty()) {
                state = ScreenState.Error("No data found for '$sessionName'")
                return@LaunchedEffect
            }
            allReadings = readings
            state = ScreenState.Loading("Computing signals…")

            val sigs = withContext(Dispatchers.Default) {
                buildSignals(readings)
            }
            signals = sigs

            state = ScreenState.Loading("Classifying motion events…")
            val result = withContext(Dispatchers.Default) {
                LocalMotionClassifier.classify(readings)
            }
            classResult = result
            state = ScreenState.Done

        } catch (e: Exception) {
            state = ScreenState.Error("Failed: ${e.message}")
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5))) {
        // Top bar
        Surface(shadowElevation = 4.dp, color = Color(0xFF212121)) {
            Row(
                modifier          = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onBack) {
                    Text("← Back", color = Color.White, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("Signal + Classification",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(sessionName,
                        color = Color(0xFFBBBBBB), fontSize = 12.sp, maxLines = 1)
                }
            }
        }

        when (val s = state) {
            is ScreenState.Idle    -> {}
            is ScreenState.Loading -> LoadingView(s.msg)
            is ScreenState.Error   -> ErrorView(s.msg, onBack)
            is ScreenState.Done    -> {
                classResult?.let { result ->
                    ResultView(signals, result, sessionName)
                }
            }
        }
    }
}

// ── Build device signals from raw readings ────────────────────────────────────
private fun buildSignals(readings: List<ImuReading>): List<DeviceSignal> {
    val t0 = readings.minOf { it.wallClockMs }
    return readings.groupBy { it.deviceId }.map { (deviceId, rds) ->
        val sorted = rds.sortedBy { it.wallClockMs }
        val times  = sorted.map { (it.wallClockMs - t0) / 1000f }
        val ax     = sorted.map { it.accelX.toFloat() }
        val ay     = sorted.map { it.accelY.toFloat() }
        val az     = sorted.map { it.accelZ.toFloat() }
        val gx     = sorted.map { it.gyroX.toFloat() }
        val gy     = sorted.map { it.gyroY.toFloat() }
        val gz     = sorted.map { it.gyroZ.toFloat() }
        val mag    = sorted.indices.map { i ->
            sqrt(ax[i] * ax[i] + ay[i] * ay[i] + az[i] * az[i])
        }
        val gyroM = sorted.indices.map { i ->
            sqrt(gx[i] * gx[i] + gy[i] * gy[i] + gz[i] * gz[i])
        }
        val dyn   = mag.map { abs(it - 9.81f) }
        val diffs = sorted.zipWithNext()
            .map { (a, b) -> (b.wallClockMs - a.wallClockMs).toFloat() }
            .filter { it > 0 }
        val fs    = if (diffs.isNotEmpty()) 1000f / diffs.median() else 17f
        val loc   = sorted.first().bodyLocation.let {
            if (it.isBlank() || it.equals("none", true))
                DeviceNames[deviceId] ?: "D$deviceId"
            else it
        }
        DeviceSignal(
            deviceId  = deviceId, times = times, accelMag = mag,
            dynamic   = dyn, gyroMag = gyroM,
            accelX = ax, accelY = ay, accelZ = az,
            gyroX  = gx, gyroY  = gy, gyroZ  = gz,
            location = loc, fs = fs,
            durationSec = times.lastOrNull() ?: 0f,
        )
    }.sortedBy { it.deviceId }
}

// ── Main result view ──────────────────────────────────────────────────────────
@Composable
private fun ResultView(
    signals:    List<DeviceSignal>,
    result:     ClassificationResult,
    sessionName: String,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // ── Stats header ──────────────────────────────────────────────────────
        Card(modifier = Modifier.fillMaxWidth(),
            colors   = CardDefaults.cardColors(containerColor = Color(0xFF212121)),
            shape    = RoundedCornerShape(12.dp)) {
            Row(modifier              = Modifier.fillMaxWidth().padding(14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly) {
                StatBox("Events",   "${result.totalEvents}",         Color.White)
                StatBox("Duration", "${result.durationSec.toInt()}s", Color.White)
                StatBox("Types",    "${result.summary.size}",         Color.White)
                StatBox("Sensors",  "${signals.size}",               Color.White)
            }
        }

        // ── Combined signal + classification per device ───────────────────────
        SectionLabel("Signal Graphs with Classified Events")
        Text("Red ▼ = detected event  ·  coloured band = predicted motion type",
            fontSize = 11.sp, color = Color(0xFF9E9E9E),
            modifier = Modifier.padding(horizontal = 4.dp))

        signals.forEach { sig ->
            val eventsForDevice = result.events.filter { it.deviceId == sig.deviceId }
            DeviceSignalCard(sig, eventsForDevice)
        }

        // ── Motion count bar chart ────────────────────────────────────────────
        if (result.summary.isNotEmpty()) {
            SectionLabel("Motion Summary")
            Card(modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(12.dp),
                colors   = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier             = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    val maxC = result.summary.values.maxOrNull() ?: 1
                    result.summary.entries.sortedByDescending { it.value }
                        .forEach { (motion, count) -> MotionBar(motion, count, maxC) }
                }
            }
        }

        // ── Legend ────────────────────────────────────────────────────────────
        val usedLabels = result.events.map { it.prediction }.distinct().sorted()
        if (usedLabels.isNotEmpty()) {
            SectionLabel("Legend")
            Card(modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(12.dp),
                colors   = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier             = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    usedLabels.chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { label ->
                                Row(verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)) {
                                    Box(Modifier.size(12.dp).clip(CircleShape)
                                        .background(motionColour(label)))
                                    Spacer(Modifier.width(6.dp))
                                    Text(label, fontSize = 11.sp, color = Color(0xFF333333))
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // ── Event list ────────────────────────────────────────────────────────
        SectionLabel("All Events (${result.events.size})")
        Card(modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(12.dp),
            colors   = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier.padding(8.dp)) {
                EventHeader()
                HorizontalDivider()
                result.events.forEach { event ->
                    EventRow(event)
                    HorizontalDivider(color = Color(0xFFF0F0F0))
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

// ── Device signal card with classification overlay ────────────────────────────
@Composable
private fun DeviceSignalCard(sig: DeviceSignal, events: List<MotionEvent>) {
    val deviceColour = DeviceColours[sig.deviceId] ?: Color.Gray
    Card(modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(modifier = Modifier.padding(12.dp)) {

            // Device header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(20.dp).clip(CircleShape)
                    .background(deviceColour),
                    contentAlignment = Alignment.Center) {
                    Text("${sig.deviceId}",
                        fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("D${sig.deviceId} — ${sig.location}",
                        fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("${sig.times.size} samples · ${sig.durationSec.toInt()}s · " +
                            "${sig.fs.toInt()} Hz · ${events.size} events detected",
                        fontSize = 10.sp, color = Color(0xFF888888))
                }
            }

            Spacer(Modifier.height(10.dp))

            // Accel magnitude graph with classification overlay
            Text("Acceleration Magnitude + Classified Events",
                fontSize = 10.sp, color = Color(0xFF666666), fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))

            Box(modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())) {

                val graphWidth  = maxOf(400.dp, (sig.durationSec * 6).dp)
                val graphHeight = 130.dp

                Canvas(modifier = Modifier.width(graphWidth).height(graphHeight)) {
                    drawSignalWithEvents(sig, events)
                }
            }

            Spacer(Modifier.height(8.dp))

            // Gyro magnitude graph
            Text("Gyroscope Magnitude",
                fontSize = 10.sp, color = Color(0xFF666666), fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))

            Box(modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())) {
                val graphWidth  = maxOf(400.dp, (sig.durationSec * 6).dp)
                val graphHeight = 80.dp

                Canvas(modifier = Modifier.width(graphWidth).height(graphHeight)) {
                    drawGyroSignal(sig, events, deviceColour)
                }
            }

            // Event labels for this device
            if (events.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("Detected on this sensor:",
                    fontSize = 10.sp, color = Color(0xFF666666))
                Spacer(Modifier.height(4.dp))
                Row(modifier             = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    events.sortedBy { it.timeSec }.forEach { ev ->
                        EventChip(ev)
                    }
                }
            }
        }
    }
}

// ── Canvas drawing ────────────────────────────────────────────────────────────
private fun DrawScope.drawSignalWithEvents(sig: DeviceSignal, events: List<MotionEvent>) {
    if (sig.accelMag.isEmpty()) return

    val w = size.width
    val h = size.height
    val pad = 8f

    val maxVal  = sig.accelMag.maxOrNull()?.coerceAtLeast(12f) ?: 12f
    val minVal  = sig.accelMag.minOrNull()?.coerceAtMost(8f) ?: 8f
    val range   = (maxVal - minVal).coerceAtLeast(1f)
    val dur     = sig.durationSec.coerceAtLeast(1f)

    fun xOf(t: Float) = pad + (t / dur) * (w - 2 * pad)
    fun yOf(v: Float) = h - pad - ((v - minVal) / range) * (h - 2 * pad)

    // Background
    drawRect(color = Color(0xFFFAFAFA))

    // Gravity reference line
    val gravY = yOf(9.81f)
    drawLine(Color(0xFFCCCCCC), Offset(pad, gravY), Offset(w - pad, gravY), 1f)

    // Coloured event bands BEHIND the signal
    events.forEach { ev ->
        val bandStart = xOf((ev.timeSec - 0.3f).coerceAtLeast(0f))
        val bandEnd   = xOf((ev.timeSec + 0.5f).coerceAtMost(dur))
        val col       = motionColour(ev.prediction)
        drawRect(
            color    = col.copy(alpha = 0.15f),
            topLeft  = Offset(bandStart, 0f),
            size     = androidx.compose.ui.geometry.Size(bandEnd - bandStart, h),
        )
        // Top colour strip
        drawRect(
            color    = col.copy(alpha = 0.7f),
            topLeft  = Offset(bandStart, 0f),
            size     = androidx.compose.ui.geometry.Size(bandEnd - bandStart, 4f),
        )
    }

    // Accel magnitude signal line
    val path   = Path()
    val colour = DeviceColours[sig.deviceId] ?: Color(0xFF2196F3)
    sig.times.forEachIndexed { i, t ->
        val x = xOf(t); val y = yOf(sig.accelMag[i])
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    drawPath(path, colour, style = Stroke(width = 1.8f))

    // Event markers (red triangles ▼)
    events.forEach { ev ->
        val x   = xOf(ev.timeSec)
        val top = pad + 2f
        val col = motionColour(ev.prediction)
        // Triangle pointing down
        val tp = Path().apply {
            moveTo(x, top + 12f)
            lineTo(x - 5f, top)
            lineTo(x + 5f, top)
            close()
        }
        drawPath(tp, col)
    }
}

private fun DrawScope.drawGyroSignal(
    sig: DeviceSignal,
    events: List<MotionEvent>,
    colour: Color,
) {
    if (sig.gyroMag.isEmpty()) return
    val w = size.width; val h = size.height; val pad = 8f
    val maxVal = sig.gyroMag.maxOrNull()?.coerceAtLeast(10f) ?: 10f
    val dur    = sig.durationSec.coerceAtLeast(1f)
    fun xOf(t: Float) = pad + (t / dur) * (w - 2 * pad)
    fun yOf(v: Float) = h - pad - (v / maxVal) * (h - 2 * pad)

    drawRect(color = Color(0xFFFAFAFA))

    // Event bands
    events.forEach { ev ->
        val col = motionColour(ev.prediction)
        drawRect(
            color   = col.copy(alpha = 0.12f),
            topLeft = Offset(xOf((ev.timeSec - 0.3f).coerceAtLeast(0f)), 0f),
            size    = androidx.compose.ui.geometry.Size(
                xOf((ev.timeSec + 0.5f).coerceAtMost(dur)) -
                        xOf((ev.timeSec - 0.3f).coerceAtLeast(0f)), h),
        )
    }

    val path = Path()
    sig.times.forEachIndexed { i, t ->
        val x = xOf(t); val y = yOf(sig.gyroMag[i])
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    drawPath(path, colour.copy(alpha = 0.7f), style = Stroke(width = 1.4f))
}

// ── Event chip ────────────────────────────────────────────────────────────────
@Composable
private fun EventChip(event: MotionEvent) {
    val col = motionColour(event.prediction)
    Row(modifier = Modifier
        .clip(RoundedCornerShape(16.dp))
        .background(col.copy(alpha = 0.12f))
        .border(1.dp, col.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(col))
        Spacer(Modifier.width(4.dp))
        Text("${event.timeSec.toInt()}s ${event.prediction}",
            fontSize = 10.sp, color = col, fontWeight = FontWeight.Medium)
        Spacer(Modifier.width(3.dp))
        Text("${(event.confidence * 100).toInt()}%",
            fontSize = 9.sp, color = col.copy(alpha = 0.7f))
    }
}

// ── Motion bar ────────────────────────────────────────────────────────────────
@Composable
private fun MotionBar(motion: String, count: Int, maxCount: Int) {
    val frac = count.toFloat() / maxCount.toFloat()
    Column {
        Row(Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape)
                    .background(motionColour(motion)))
                Spacer(Modifier.width(6.dp))
                Text(motion, fontSize = 12.sp, color = Color(0xFF333333))
            }
            Text("$count", fontWeight = FontWeight.Bold,
                fontSize = 13.sp, color = motionColour(motion))
        }
        Spacer(Modifier.height(3.dp))
        Box(Modifier.fillMaxWidth().height(6.dp)
            .clip(RoundedCornerShape(3.dp)).background(Color(0xFFF0F0F0))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(frac)
                .clip(RoundedCornerShape(3.dp)).background(motionColour(motion)))
        }
    }
}

// ── Event list rows ───────────────────────────────────────────────────────────
@Composable
private fun EventHeader() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text("Time",   fontWeight = FontWeight.Bold, fontSize = 11.sp,
            color = Color(0xFF666666), modifier = Modifier.width(48.dp))
        Text("Sensor", fontWeight = FontWeight.Bold, fontSize = 11.sp,
            color = Color(0xFF666666), modifier = Modifier.width(90.dp))
        Text("Motion", fontWeight = FontWeight.Bold, fontSize = 11.sp,
            color = Color(0xFF666666), modifier = Modifier.weight(1f))
        Text("Conf",   fontWeight = FontWeight.Bold, fontSize = 11.sp,
            color = Color(0xFF666666), modifier = Modifier.width(40.dp),
            textAlign = TextAlign.End)
    }
}

@Composable
private fun EventRow(event: MotionEvent) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text("${event.timeSec.toInt()}s", fontSize = 11.sp,
            color = Color(0xFF777777), modifier = Modifier.width(48.dp))
        Text(event.location, fontSize = 11.sp,
            color = Color(0xFF555555), modifier = Modifier.width(90.dp))
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape)
                .background(motionColour(event.prediction)))
            Spacer(Modifier.width(5.dp))
            Text(event.prediction, fontSize = 11.sp,
                fontWeight = FontWeight.Medium, color = Color(0xFF212121))
        }
        Text("${(event.confidence * 100).toInt()}%",
            fontSize = 11.sp, fontWeight = FontWeight.Bold,
            color = motionColour(event.prediction),
            modifier = Modifier.width(40.dp), textAlign = TextAlign.End)
    }
}

// ── Misc helpers ──────────────────────────────────────────────────────────────
@Composable
private fun SectionLabel(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp,
        color = Color(0xFF212121), modifier = Modifier.padding(vertical = 2.dp))
}

@Composable
private fun StatBox(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = color)
        Text(label, fontSize = 10.sp, color = color.copy(alpha = 0.7f))
    }
}

@Composable
private fun LoadingView(message: String) {
    Column(Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        CircularProgressIndicator(color = Color(0xFF2196F3), strokeWidth = 4.dp)
        Spacer(Modifier.height(20.dp))
        Text(message, color = Color(0xFF555555), textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp))
    }
}

@Composable
private fun ErrorView(message: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Text("⚠", fontSize = 48.sp)
        Spacer(Modifier.height(12.dp))
        Text("Failed", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Text(message, color = Color(0xFF757575), textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onBack) { Text("Go back") }
    }
}

// ── Math helpers ──────────────────────────────────────────────────────────────
private fun List<Float>.median(): Float {
    if (isEmpty()) return 0f
    val s = sorted()
    return if (s.size % 2 == 0) (s[s.size / 2 - 1] + s[s.size / 2]) / 2f
    else s[s.size / 2]
}