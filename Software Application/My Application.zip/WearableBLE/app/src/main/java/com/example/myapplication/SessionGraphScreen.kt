package com.example.myapplication

import android.graphics.Color
import android.view.ViewGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.myapplication.db.BLEDatabase
import com.example.myapplication.db.ImuReading
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ── Data classes ──────────────────────────────────────────────────────────────

data class DeviceChartData(
    val deviceId: Int,
    val location: String,
    val readings: List<ImuReading>,
    val startMs: Long
)

// ── Session Graph Screen ──────────────────────────────────────────────────────

@Composable
fun SessionGraphScreen(
    sessionName: String,
    db: BLEDatabase,
    onBack: () -> Unit
) {
    val deviceData     = remember { mutableStateListOf<DeviceChartData>() }
    val isLoading      = remember { mutableStateOf(true) }
    val selectedTab    = remember { mutableIntStateOf(0) }
    val selectedPoint  = remember { mutableStateOf("") }

    // Tab labels
    val tabs = listOf("Overview") + (1..4).map { "D$it" }

    LaunchedEffect(sessionName) {
        withContext(Dispatchers.IO) {
            val allSessions = db.imuDao().getAllSessions()
            val session = allSessions.find { it.sessionName == sessionName }
            val sessionId = session?.sessionId ?: 0L
            val allReadings = db.imuDao().getSessionReadings(sessionId)
            val startMs = allReadings.minOfOrNull { it.wallClockMs } ?: 0L
            val byDevice = allReadings.groupBy { it.deviceId }

            withContext(Dispatchers.Main) {
                deviceData.clear()
                byDevice.toSortedMap().forEach { (devId, readings) ->
                    val loc = readings.firstOrNull()?.bodyLocation ?: "Device $devId"
                    deviceData.add(DeviceChartData(devId, loc, readings, startMs))
                }
                isLoading.value = false
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {

        // ── Top bar ───────────────────────────────────────────────────────────
        Surface(shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Text("←", style = MaterialTheme.typography.titleLarge)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(sessionName, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (isLoading.value) "Loading..."
                        else "${deviceData.size} devices — ${deviceData.sumOf { it.readings.size }} total rows",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        if (isLoading.value) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (deviceData.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No data found for: $sessionName")
            }
        } else {

            // ── Selected point info bar ───────────────────────────────────────
            if (selectedPoint.value.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        selectedPoint.value,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }

            // ── Tab row ───────────────────────────────────────────────────────
            val availableTabs = listOf("Overview") + deviceData.map { "D${it.deviceId} ${it.location.take(8)}" }
            ScrollableTabRow(
                selectedTabIndex = selectedTab.intValue.coerceAtMost(availableTabs.lastIndex),
                modifier = Modifier.fillMaxWidth(),
                edgePadding = 8.dp
            ) {
                availableTabs.forEachIndexed { index, label ->
                    Tab(
                        selected = selectedTab.intValue == index,
                        onClick  = {
                            selectedTab.intValue = index
                            selectedPoint.value = ""
                        },
                        text = {
                            Text(label, style = MaterialTheme.typography.labelSmall)
                        }
                    )
                }
            }

            // ── Content ───────────────────────────────────────────────────────
            if (selectedTab.intValue == 0) {
                // Overview — all devices compared
                OverviewTab(
                    deviceData = deviceData,
                    onPointSelected = { selectedPoint.value = it }
                )
            } else {
                // Individual device tab
                val devIndex = selectedTab.intValue - 1
                if (devIndex < deviceData.size) {
                    DeviceDetailTab(
                        data = deviceData[devIndex],
                        onPointSelected = { selectedPoint.value = it }
                    )
                }
            }
        }
    }
}

// ── Overview Tab — all devices on same chart ──────────────────────────────────

@Composable
fun OverviewTab(
    deviceData: List<DeviceChartData>,
    onPointSelected: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    val deviceColors = listOf(
        Color.rgb(33, 150, 243),   // blue   — D1
        Color.rgb(76, 175, 80),    // green  — D2
        Color.rgb(255, 152, 0),    // orange — D3
        Color.rgb(233, 30, 99),    // pink   — D4
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Summary cards row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            deviceData.forEachIndexed { idx, data ->
                val color = deviceColors.getOrElse(idx) { Color.GRAY }
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            "D${data.deviceId}",
                            style = MaterialTheme.typography.labelMedium,
                            color = androidx.compose.ui.graphics.Color(color)
                        )
                        Text(
                            data.location.replace("_", " "),
                            style = MaterialTheme.typography.labelSmall
                        )
                        Text(
                            "${data.readings.size} rows",
                            style = MaterialTheme.typography.labelSmall
                        )
                        val dur = if (data.readings.size > 1) {
                            (data.readings.last().wallClockMs - data.readings.first().wallClockMs) / 1000.0
                        } else 0.0
                        Text(
                            "${String.format(java.util.Locale.US, "%.1f", dur)}s",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }

        // Accel magnitude comparison — all devices
        Text("Accel Magnitude — All Devices", style = MaterialTheme.typography.labelMedium)
        Text(
            "Pinch to zoom · Drag to pan · Tap point for timestamp",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.outline
        )

        val globalStart = deviceData.minOfOrNull { it.startMs } ?: 0L

        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            factory = { context ->
                LineChart(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setupChart(this)
                    setOnChartValueSelectedListener(object : OnChartValueSelectedListener {
                        override fun onValueSelected(e: Entry?, h: Highlight?) {
                            e?.let {
                                val t = it.x
                                val v = it.y
                                onPointSelected("t=%.2fs  |a|=%.2f m/s²".format(t, v))
                            }
                        }
                        override fun onNothingSelected() { onPointSelected("") }
                    })
                }
            },
            update = { chart ->
                val dataSets = deviceData.mapIndexed { idx, data ->
                    val color = deviceColors.getOrElse(idx) { Color.GRAY }
                    val entries = data.readings.map { r ->
                        val t = (r.wallClockMs - globalStart) / 1000f
                        val mag = Math.sqrt(
                            (r.accelX * r.accelX + r.accelY * r.accelY + r.accelZ * r.accelZ).toDouble()
                        ).toFloat()
                        Entry(t, mag)
                    }
                    LineDataSet(entries, "D${data.deviceId} ${data.location.take(10)}").apply {
                        this.color = color
                        setDrawCircles(false)
                        lineWidth = 1.2f
                        setDrawValues(false)
                        mode = LineDataSet.Mode.LINEAR
                        axisDependency = YAxis.AxisDependency.LEFT
                    }
                }
                chart.data = LineData(dataSets)
                chart.invalidate()
            }
        )

        // Peak impact counts per device
        Text("Impact Events per Device (>15 m/s²)", style = MaterialTheme.typography.labelMedium)
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                deviceData.forEachIndexed { idx, data ->
                    val color = deviceColors.getOrElse(idx) { Color.GRAY }
                    val impacts = data.readings.count { r ->
                        val mag = Math.sqrt(
                            (r.accelX * r.accelX + r.accelY * r.accelY + r.accelZ * r.accelZ).toDouble()
                        )
                        Math.abs(mag - 9.81) > 15.0
                    }
                    val diffs = data.readings.zipWithNext().map {
                        it.second.wallClockMs - it.first.wallClockMs
                    }
                    val hz = if (diffs.isNotEmpty()) 1000.0 / diffs.average() else 0.0

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "D${data.deviceId} — ${data.location.replace("_", " ")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = androidx.compose.ui.graphics.Color(color)
                        )
                        Text(
                            "$impacts impacts  |  ${String.format(java.util.Locale.US, "%.1f", hz)}Hz",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (idx < deviceData.lastIndex) HorizontalDivider()
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

// ── Device Detail Tab ─────────────────────────────────────────────────────────

@Composable
fun DeviceDetailTab(
    data: DeviceChartData,
    onPointSelected: (String) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Stats card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("D${data.deviceId} — ${data.location.replace("_"," ")}",
                    style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(8.dp))
                val duration = if (data.readings.size > 1)
                    (data.readings.last().wallClockMs - data.readings.first().wallClockMs) / 1000.0
                else 0.0
                val diffs = data.readings.zipWithNext().map {
                    it.second.wallClockMs - it.first.wallClockMs
                }
                val hz = if (diffs.isNotEmpty()) 1000.0 / diffs.average() else 0.0
                val maxMag = data.readings.maxOfOrNull { r ->
                    Math.sqrt((r.accelX*r.accelX + r.accelY*r.accelY + r.accelZ*r.accelZ).toDouble())
                } ?: 0.0
                val impacts = data.readings.count { r ->
                    Math.abs(Math.sqrt((r.accelX*r.accelX + r.accelY*r.accelY + r.accelZ*r.accelZ).toDouble()) - 9.81) > 15.0
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    StatItem("Samples", "${data.readings.size}")
                    StatItem("Duration", "${String.format(java.util.Locale.US, "%.1f", duration)}s")
                    StatItem("Rate", "${String.format(java.util.Locale.US, "%.1f", hz)}Hz")
                    StatItem("Max|a|", "${String.format(java.util.Locale.US, "%.1f", maxMag)}")
                    StatItem("Impacts", "$impacts")
                }
            }
        }

        Text(
            "Pinch to zoom · Drag to pan · Tap point for exact time",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.outline
        )

        // Accel XYZ
        Text("Accelerometer XYZ (m/s²)", style = MaterialTheme.typography.labelMedium)
        ImuLineChart(
            readings = data.readings,
            startMs  = data.startMs,
            channels = listOf(
                ChartChannel("X", Color.RED)   { it.accelX },
                ChartChannel("Y", Color.rgb(0,180,0)) { it.accelY },
                ChartChannel("Z", Color.BLUE)  { it.accelZ },
            ),
            onPointSelected = { t, v, label ->
                onPointSelected("Accel $label  t=${String.format(java.util.Locale.US,"%.3f",t)}s  val=${String.format(java.util.Locale.US,"%.3f",v)} m/s²")
            }
        )

        // Accel magnitude
        Text("Accel Magnitude + Impacts (m/s²)", style = MaterialTheme.typography.labelMedium)
        ImuLineChart(
            readings = data.readings,
            startMs  = data.startMs,
            channels = listOf(
                ChartChannel("|a|", Color.rgb(128,0,128)) { r ->
                    Math.sqrt((r.accelX*r.accelX + r.accelY*r.accelY + r.accelZ*r.accelZ).toDouble()).toFloat()
                },
            ),
            onPointSelected = { t, v, label ->
                onPointSelected("|a|  t=${String.format(java.util.Locale.US,"%.3f",t)}s  val=${String.format(java.util.Locale.US,"%.3f",v)} m/s²  dynamic=${String.format(java.util.Locale.US,"%.2f",Math.abs(v-9.81))} m/s²")
            }
        )

        // Gyro XYZ
        Text("Gyroscope XYZ (deg/s)", style = MaterialTheme.typography.labelMedium)
        ImuLineChart(
            readings = data.readings,
            startMs  = data.startMs,
            channels = listOf(
                ChartChannel("X", Color.rgb(200,0,0))   { it.gyroX },
                ChartChannel("Y", Color.rgb(0,150,0))   { it.gyroY },
                ChartChannel("Z", Color.rgb(0,0,200))   { it.gyroZ },
            ),
            onPointSelected = { t, v, label ->
                onPointSelected("Gyro $label  t=${String.format(java.util.Locale.US,"%.3f",t)}s  val=${String.format(java.util.Locale.US,"%.3f",v)} deg/s")
            }
        )

        Spacer(modifier = Modifier.height(32.dp))
    }
}

// ── Stat Item ─────────────────────────────────────────────────────────────────

@Composable
fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.bodyMedium)
        Text(label, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.outline)
    }
}

// ── Chart setup helper ────────────────────────────────────────────────────────

fun setupChart(chart: LineChart) {
    chart.description.isEnabled = false
    chart.setTouchEnabled(true)
    chart.isDragEnabled = true
    chart.setScaleEnabled(true)
    chart.setPinchZoom(true)
    chart.setDrawGridBackground(false)
    chart.setBackgroundColor(Color.TRANSPARENT)

    chart.xAxis.apply {
        position = XAxis.XAxisPosition.BOTTOM
        setDrawGridLines(true)
        granularity = 1f
        valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float) = "${String.format(java.util.Locale.US, "%.1f", value)}s"
        }
        textColor = Color.GRAY
        gridColor = Color.LTGRAY
    }
    chart.axisLeft.apply {
        setDrawGridLines(true)
        textColor = Color.GRAY
        gridColor = Color.LTGRAY
    }
    chart.axisRight.isEnabled = false
    chart.legend.apply {
        isEnabled = true
        verticalAlignment = Legend.LegendVerticalAlignment.TOP
        horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT
        textColor = Color.DKGRAY
    }
}

// ── Chart Channel ─────────────────────────────────────────────────────────────

data class ChartChannel(
    val label: String,
    val color: Int,
    val getValue: (ImuReading) -> Float
)

// ── IMU Line Chart ────────────────────────────────────────────────────────────

@Composable
fun ImuLineChart(
    readings: List<ImuReading>,
    startMs: Long,
    channels: List<ChartChannel>,
    onPointSelected: (t: Float, v: Float, label: String) -> Unit
) {
    var selectedChannel by remember { mutableStateOf("") }

    AndroidView(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp),
        factory = { context ->
            LineChart(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setupChart(this)
                setOnChartValueSelectedListener(object : OnChartValueSelectedListener {
                    override fun onValueSelected(e: Entry?, h: Highlight?) {
                        e?.let {
                            onPointSelected(it.x, it.y, selectedChannel)
                        }
                    }
                    override fun onNothingSelected() {}
                })
            }
        },
        update = { chart ->
            val dataSets = channels.map { channel ->
                val entries = readings.map { r ->
                    val t = (r.wallClockMs - startMs) / 1000f
                    Entry(t, channel.getValue(r))
                }
                LineDataSet(entries, channel.label).apply {
                    color = channel.color
                    setDrawCircles(entries.size < 100)  // only show dots for small datasets
                    circleRadius = 2f
                    setCircleColor(channel.color)
                    lineWidth = 1.2f
                    setDrawValues(false)
                    mode = LineDataSet.Mode.LINEAR
                    setDrawHighlightIndicators(true)
                    highLightColor = Color.YELLOW
                }
            }
            selectedChannel = channels.firstOrNull()?.label ?: ""
            chart.data = LineData(dataSets)
            chart.invalidate()
        }
    )
}