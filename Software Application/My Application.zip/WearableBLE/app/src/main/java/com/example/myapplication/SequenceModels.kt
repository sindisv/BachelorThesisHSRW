package com.example.myapplication

/**
 * Models for capturing the ground-truth sequence a user actually performed
 * during a session. Entered at session end, becomes labelled training data.
 *
 * Modes:
 *   - STRUCTURED: ordered entries (single motions or combos), optional repeat
 *     counts, optional "don't know the count".
 *   - WHOLE_SESSION_ONE_MOTION: the entire session was a single motion type
 *     (e.g. "all jabs"), no rep count needed — every detected strike is that type.
 *   - FREE_ROUND: unstructured free sparring; stored as context, not aligned.
 *   - FREE_TEXT: typed description.
 */

enum class SequenceMode { STRUCTURED, WHOLE_SESSION_ONE_MOTION, FREE_ROUND, FREE_TEXT }

data class SequenceEntry(
    val motions: List<String>,   // e.g. ["Jab"] or ["Jab","Cross","Hook"]
    val repeat: Int,             // how many times this entry repeats (1 = once)
    val countKnown: Boolean,     // false if user chose "I don't know the count"
)

data class PerformedSequence(
    val mode: SequenceMode,
    val entries: List<SequenceEntry> = emptyList(),
    val wholeSessionMotion: String = "",   // used when mode = WHOLE_SESSION_ONE_MOTION
    val freeText: String = "",
) {
    // For backwards compatibility with earlier code paths
    val isFreeSequence: Boolean get() = mode == SequenceMode.FREE_TEXT || mode == SequenceMode.FREE_ROUND

    fun flattenExpected(): List<String> {
        return when (mode) {
            SequenceMode.STRUCTURED -> {
                val out = mutableListOf<String>()
                for (e in entries) {
                    val reps = if (e.countKnown) e.repeat else 1
                    repeat(reps) { out.addAll(e.motions) }
                }
                out
            }
            SequenceMode.WHOLE_SESSION_ONE_MOTION -> emptyList() // count unknown by design
            else -> emptyList()
        }
    }

    fun hasUnknownCount(): Boolean =
        mode == SequenceMode.WHOLE_SESSION_ONE_MOTION ||
                entries.any { !it.countKnown }

    fun describe(): String = when (mode) {
        SequenceMode.WHOLE_SESSION_ONE_MOTION ->
            "Whole session: $wholeSessionMotion (all strikes)"
        SequenceMode.FREE_ROUND ->
            "Free round / sparring" + if (freeText.isNotBlank()) " — $freeText" else ""
        SequenceMode.FREE_TEXT ->
            freeText.ifBlank { "(free text, no detail)" }
        SequenceMode.STRUCTURED -> {
            if (entries.isEmpty()) "(no sequence entered)"
            else entries.joinToString("  +  ") { e ->
                val combo = e.motions.joinToString("-")
                when {
                    !e.countKnown -> "$combo (×?)"
                    e.repeat == 1 -> combo
                    else          -> "$combo ×${e.repeat}"
                }
            }
        }
    }
}

object MotionVocabulary {
    val punches = listOf("Jab", "Cross", "Hook", "Uppercut")
    val kicks   = listOf("Low Kick", "Mid Kick", "High Kick", "Front Kick", "Side Kick")
    val all     = punches + kicks
}