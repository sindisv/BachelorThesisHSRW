package com.example.myapplication.ble

import android.annotation.SuppressLint
import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import java.util.UUID

// ── Device configurations ─────────────────────────────────────────────────────
data class DeviceConfig(
    val name: String,
    val serviceUuid: UUID,
    val characteristicUuid: UUID,
    val deviceId: Int,
    val bodyLocation: String
)

val DEVICES = listOf(
    DeviceConfig(
        name = "WearableBLE",
        serviceUuid = UUID.fromString("12345678-1234-1234-1234-123456789abc"),
        characteristicUuid = UUID.fromString("87654321-4321-4321-4321-cba987654321"),
        deviceId = 1,
        bodyLocation = "dominant_wrist"
    ),
    DeviceConfig(
        name = "SensePlus_2",
        serviceUuid = UUID.fromString("23456789-2345-2345-2345-234567890abc"),
        characteristicUuid = UUID.fromString("98765432-5432-5432-5432-dcba98765432"),
        deviceId = 2,
        bodyLocation = "nondominant_wrist"
    ),
    DeviceConfig(
        name = "SensePlus_3",
        serviceUuid = UUID.fromString("34567890-3456-3456-3456-345678901234"),
        characteristicUuid = UUID.fromString("09876543-6543-6543-6543-edcba9876543"),
        deviceId = 3,
        bodyLocation = "dominant_ankle"
    ),
    DeviceConfig(
        name = "SensePlus_4",
        serviceUuid = UUID.fromString("45678901-4567-4567-4567-456789012345"),
        characteristicUuid = UUID.fromString("10987654-7654-7654-7654-fedcba987654"),
        deviceId = 4,
        bodyLocation = "dominant_shin"
    )
)

val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

data class DeviceState(
    val config: DeviceConfig,
    var gatt: BluetoothGatt? = null,
    var connected: Boolean = false,
    var rowCount: Int = 0
)

@SuppressLint("MissingPermission")
class BleManager(
    private val context: Context,
    private val onSamplesReceived: (samples: List<ImuSample>, deviceId: Int, bodyLocation: String) -> Unit,
    private val onDeviceStateChanged: (deviceId: Int, connected: Boolean) -> Unit
) {
    private val tag = "BleManager"
    private val scanTimeout = 20000L

    private val bluetoothAdapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var scanner: BluetoothLeScanner? = null
    private val handler = Handler(Looper.getMainLooper())

    private val deviceStates = DEVICES.associateWith { DeviceState(it) }.toMutableMap()

    // ── Scan ──────────────────────────────────────────────────────────────────
    fun startScan() {
        if (!hasPermission(Manifest.permission.BLUETOOTH_SCAN)) {
            Log.e(tag, "Missing BLUETOOTH_SCAN permission")
            return
        }
        scanner = bluetoothAdapter?.bluetoothLeScanner

        val filters = DEVICES.map { device ->
            ScanFilter.Builder()
                .setServiceUuid(android.os.ParcelUuid(device.serviceUuid))
                .build()
        }
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        Log.d(tag, "Scanning for ${DEVICES.size} devices...")
        scanner?.startScan(filters, settings, scanCallback)
        handler.postDelayed({ stopScan() }, scanTimeout)
    }

    fun stopScan() {
        if (hasPermission(Manifest.permission.BLUETOOTH_SCAN)) {
            scanner?.stopScan(scanCallback)
            Log.d(tag, "Scan stopped")
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val matchingDevice = DEVICES.find { device ->
                result.scanRecord?.serviceUuids?.any {
                    it.uuid == device.serviceUuid
                } == true
            } ?: return

            val state = deviceStates[matchingDevice] ?: return
            if (state.connected || state.gatt != null) return

            Log.d(tag, "Found ${matchingDevice.name} at ${result.device.address}")
            connectTo(result.device, matchingDevice)
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(tag, "Scan failed: $errorCode")
        }
    }

    // ── Connect ───────────────────────────────────────────────────────────────
    private fun connectTo(device: BluetoothDevice, config: DeviceConfig) {
        if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) return
        Log.d(tag, "Connecting to ${config.name}...")
        val gatt = device.connectGatt(
            context, false, createGattCallback(config), BluetoothDevice.TRANSPORT_LE
        )
        deviceStates[config]?.gatt = gatt
    }

    fun disconnectAll() {
        deviceStates.values.forEach { state ->
            if (hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
                state.gatt?.disconnect()
                state.gatt?.close()
                state.gatt = null
                state.connected = false
            }
        }
        Log.d(tag, "All devices disconnected")
    }

    fun getConnectedCount(): Int = deviceStates.values.count { it.connected }

    fun isDeviceConnected(deviceId: Int): Boolean =
        deviceStates.values.find { it.config.deviceId == deviceId }?.connected ?: false

    // ── GATT Callback ───────────────────────────────────────────────────────
    private fun createGattCallback(config: DeviceConfig) = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    Log.d(tag, "${config.name} connected — requesting priority + MTU")
                    // Request fastest connection interval (helps multi-sensor rate)
                    gatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
                    // Request larger MTU (so batched packets fit if firmware sends them)
                    val requested = gatt.requestMtu(247)
                    // SAFETY NET: if requestMtu returns false (call rejected),
                    // the onMtuChanged callback will never fire, so go straight
                    // to service discovery here.
                    if (!requested) {
                        Log.w(tag, "${config.name} requestMtu rejected — discovering services directly")
                        gatt.discoverServices()
                    }
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    Log.d(tag, "${config.name} disconnected (status=$status)")
                    deviceStates[config]?.connected = false
                    deviceStates[config]?.gatt?.close()
                    deviceStates[config]?.gatt = null
                    handler.post { onDeviceStateChanged(config.deviceId, false) }
                    handler.postDelayed({
                        val state = deviceStates[config]
                        if (state?.connected == false && state.gatt == null) {
                            Log.d(tag, "${config.name} attempting auto-reconnect...")
                            startScan()
                        }
                    }, 3000)
                }
            }
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            // KEY FIX: always proceed to service discovery, regardless of MTU
            // success/failure. MTU is optional; service discovery is mandatory.
            // The old code only discovered on GATT_SUCCESS, which is why devices
            // connected (green light) but were never registered by the app.
            Log.d(tag, "${config.name} MTU=$mtu status=$status — discovering services")
            gatt.discoverServices()
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                Log.e(tag, "${config.name} service discovery failed: $status")
                return
            }
            val characteristic = gatt
                .getService(config.serviceUuid)
                ?.getCharacteristic(config.characteristicUuid)
            if (characteristic == null) {
                Log.e(tag, "${config.name} characteristic not found")
                return
            }
            if (hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
                gatt.setCharacteristicNotification(characteristic, true)
                val descriptor = characteristic.getDescriptor(CCCD_UUID)
                descriptor?.let {
                    @Suppress("DEPRECATION")
                    it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    @Suppress("DEPRECATION")
                    gatt.writeDescriptor(it)
                    Log.d(tag, "${config.name} notifications enabled ✓")
                    deviceStates[config]?.connected = true
                    handler.post { onDeviceStateChanged(config.deviceId, true) }
                }
            }
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            if (characteristic.uuid == config.characteristicUuid) {
                val samples = parsePayload(value, config)
                if (samples.isNotEmpty()) {
                    handler.post {
                        onSamplesReceived(samples, config.deviceId, config.bodyLocation)
                    }
                }
            }
        }
    }

    // ── Payload Parser ────────────────────────────────────────────────────────
    // Handles THREE formats automatically:
    //   A) BATCHED packet (new firmware): byte0 = sample count N,
    //      then N × 28-byte blocks of [ts(4) ax ay az gx gy gz]
    //   B) Legacy 44-byte single packet: ts + accel + gyro + quat
    //   C) Legacy 20-byte single packet (MTU not negotiated)
    private fun parsePayload(bytes: ByteArray, config: DeviceConfig): List<ImuSample> {
        // Detect batched format: byte0 is a small count and size fits N*28+1
        if (bytes.isNotEmpty()) {
            val possibleCount = bytes[0].toInt() and 0xFF
            val needed = 1 + possibleCount * 28
            if (possibleCount in 1..8 && bytes.size >= needed) {
                return parseBatched(bytes, possibleCount)
            }
        }

        val buf = java.nio.ByteBuffer.wrap(bytes)
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
        return when {
            bytes.size >= 44 -> {
                val ts = buf.int.toLong() and 0xFFFFFFFFL
                val ax = buf.float; val ay = buf.float; val az = buf.float
                val gx = buf.float; val gy = buf.float; val gz = buf.float
                val qw = buf.float; val qx = buf.float
                val qy = buf.float; val qz = buf.float
                listOf(ImuSample(ts, ax, ay, az, gx, gy, gz, qw, qx, qy, qz))
            }
            bytes.size >= 20 -> {
                val ts = buf.int.toLong() and 0xFFFFFFFFL
                val ax = buf.float; val ay = buf.float; val az = buf.float
                val gx = buf.float
                listOf(ImuSample(ts, ax, ay, az, gx, 0f, 0f, 1f, 0f, 0f, 0f))
            }
            else -> {
                Log.w(tag, "${config.name} packet too small (${bytes.size}) — skipping")
                emptyList()
            }
        }
    }

    private fun parseBatched(bytes: ByteArray, count: Int): List<ImuSample> {
        val buf = java.nio.ByteBuffer.wrap(bytes)
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
        buf.position(1)
        val out = ArrayList<ImuSample>(count)
        repeat(count) {
            val ts = buf.int.toLong() and 0xFFFFFFFFL
            val ax = buf.float; val ay = buf.float; val az = buf.float
            val gx = buf.float; val gy = buf.float; val gz = buf.float
            out.add(ImuSample(ts, ax, ay, az, gx, gy, gz, 1f, 0f, 0f, 0f))
        }
        return out
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) ==
                PackageManager.PERMISSION_GRANTED
}